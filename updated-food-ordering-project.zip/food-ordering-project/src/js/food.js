$(document).ready(function () {

    // alert(1);
    fetchData();


});
function addToCart(specificFoodItem) {
    // alert(specificFoodItem.name);
    var userid = sessionStorage.getItem("userid");
    if (!userid) {
        window.location.href = "../pages/login.html"
    }
    else {
        updateUserCart(specificFoodItem);
    }


    // alert(typeof (specificFoodItem));

}

function updateUserCart(specificFoodItem) {
    const userCartUrl = "http://localhost:3000/userCart";
    const addCartItem = {
        type: "food",
        quantity: 1,
        userMenuId: Number(specificFoodItem.id)
    };
    $.ajax({
        url: userCartUrl,
        type: "post",
        data: addCartItem,
        dataType: 'JSON',
        success: function (userCartResponse) {
            console.log("user cart ressponse: ", userCartResponse);
            // $('form').submit();
            // alert(22);
            fetchUserData(userCartResponse.id);

        },
        error: function () {
            alert("Could not add to cart. \n Sorry trya again later.");
        }

    });

}

function fetchUserData(userCartID) {

    alert(userCartID);
    const userId = sessionStorage.getItem("userid");
    const userUrl = "http://localhost:3000/users/" + userId;
    $.getJSON(userUrl, function (userData) {
        updateUserData(userCartID, userData);
        // alert("abcd");
    });
    // $.getJSON("http://localhost:3000/users/" + userId, function (data) {


}
function updateUserData(userCartID, userData) {

    alert(userCartID);
    console.log(userData);
    console.log(userData.cart);
    // alert(userCartID);
    // console.log(userData.cart);
    alert("hey");
    const userCart = userData.cart;
    let data;
    userData.cart = userData.cart.push(userCartID);
    console.log("this is user cart: ", userData);
    alert("userData cart");

    $.ajax({
        type: "put",
        // url: "http://localhost:3000/users// +userId{`cart`}" ,
        url: "http://localhost:3000/users/" + userId,
        data: userData,
        dataType: "json",
        success: function () {
            alert('Added to your cart');
            // do what you want on success.
        }
    });



    // if (userCart) {
    //     alert("not empty");
    //     console.log(userData.cart);
    //     data = userCart.push(userCartID);
    // $.ajax({
    //     type: "PATCH",
    //     // url: "http://localhost:3000/users// +userId{`cart`}" ,
    //     url: "http://localhost:3000/users/" + userData.id,
    //     data: {
    //         cart: data
    //     },
    //     dataType: "json",
    //     success: function () {
    //         alert("Quantity updated.");
    //     }
    // });
    // } else {
    //     alert("empty");
    //     data = [Number(userCartID)];
    //     $.ajax({
    //         type: "PATCH",
    //         // url: "http://localhost:3000/users// +userId{`cart`}" ,
    //         url: "http://localhost:3000/users/" + userData.id,
    //         data: {
    //             cart: data
    //         },
    //         dataType: "json",
    //         success: function () {
    //             alert("Quantity updated.");
    //         }
    //     });
    // }

}

function fetchData() {
    $.getJSON("http://localhost:3000/menu",
        function (data) {
            const foodItems = data[0];
            for (let j = 0; j < foodItems.food.length; j++) {
                let specificFoodItem = foodItems.food[j];
                $('#burgers').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>" +
                    "<div class='col-md-3 food-image'><img src='../" + specificFoodItem.img + "'></div><div class='col-md-9'" +
                    "><h3 class='food-title'><span class='food-name'>" + specificFoodItem.name + "</span><span class='food-price float-right'>Rs."
                    + specificFoodItem.price + "</span></h3><p class='food-ingredients'>" + specificFoodItem.description + "</p>" +
                    "<a class='btn btn-outline-success float-end' id='login-btn' onclick='addToCart(" + JSON.stringify(specificFoodItem) +
                    ")'  role='button'>Add to Cart</a>" +
                    "</div>");
            }

            for (let j = 0; j < data[1].desserts.length; j++) {
                $('#dessert').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>" +
                    "<div class='col-md-3 food-image'><img src='../" + data[1].desserts[j].img + "'></div><div class='col-md-9'" +
                    "><h3 class='food-title'><span class='food-name'>" + data[1].desserts[j].name + "</span><span class='food-price float-right'>Rs."
                    + data[1].desserts[j].price + "</span></h3><p class='food-ingredients'>" + data[1].desserts[j].description + "</p></div>");
            }


            for (let j = 0; j < data[2].drinks.length; j++) {
                $('#drink').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>" +
                    "<div class='col-md-3 food-image'><img src='../" + data[2].drinks[j].img + "'></div><div class='col-md-9'" +
                    "><h3 class='food-title'><span class='food-name'>" + data[2].drinks[j].name + "</span><span class='food-price float-right'>Rs."
                    + data[2].drinks[j].price + "</span></h3><p class='food-ingredients'>" + data[2].drinks[j].description + "</p></div>");
            }
        });
}
