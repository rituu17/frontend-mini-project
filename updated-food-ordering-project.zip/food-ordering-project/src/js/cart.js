function showCartModal() {
    const userId = sessionStorage.getItem("userid");
    $.getJSON("http://localhost:3000/users/" + userId, function (data) {
        const cartItem = data.cart;
        // if cart is undefined then dont call the fetCartItem() method

        if (!cartItem) {
            //cart item is undefined means users dont have items in his cart
            hideCartDetails();

        } else {
            // user has some items in his cart;
            $("#empty-cart-image").hide();
            fetchCartItem(cartItem);
        }
    });
}

function hideCartDetails() {

    $("#cart-headings").hide();
    $("#total-text").hide();
    $("#checkout-btn").hide();
    $("#empty-cart-image").show();
    $("#cart-modal-heading").html("Your Food cart is empty");






}

function fetchCartItem(cartItem) {

    if (cartItem) {

        $.getJSON("http://localhost:3000/menu", function (menuData) {
            fetchCompleteCartObject(cartItem, menuData);
            document.getElementById("t-body").innerHTML = "";

        });
    }
}
function fetchCompleteCartObject(cartItem, menu) {
    // alert(12);
    var userId = sessionStorage.getItem("userid");
    console.log(userId)
    $.getJSON("http://localhost:3000/users/"+userId, function (userCart) {
        // console.log("this is user cart: ", userCart);
        // if(!cartItem){
            //console.log(cartItem)
           // console.log(menu)
            //console.log(userCart);
       updateCart(cartItem, menu, userCart);
        // }else{
        // alert("your cart is empty");
        // }
    });
}

function updateCart(cartItem, menu, userCart) {
    // console.log("cartItem: ", cartItem)

    // for (var i = 0; i < cartItem.length; i++) {
    //     // const cartItems = "cartItem[]";
    //     var specificCartId = cartItem[i];
    //    // console.log(specificCartId)
    //     fetchCartItems(specificCartId, userCart, menu);
    // }
    fetchCartItems(cartItem, userCart, menu);
}
var usercart2 = [];
function fetchCartItems(specificCartId, userCart, menu) {
   //console.log("this is menu: ", specificCartId);
  // console.log(userCart.cart)
    for (var i = 0; i < userCart.cart.length; i++) {
        if (specificCartId[i] == userCart.cart[i]) {
            $.getJSON("http://localhost:3000/userCart/"+userCart.cart[i], function (userCart1) {
            type = userCart1.type;
            quantity = userCart1.quantity;
            //console.log(" type: ", type, " quantity: ", quantity);
          // console.log(userCart1)
            usercart2.push(userCart1)
         
            });
        }
    }
    //console.log(JSON.stringify(usercart2))
    addFood(usercart2, menu);
    
}

var total = 0;
function addFood(specificUserCart, completeMenu) {
  //console.log("Bushgan "+ JSON.stringify(specificUserCart[0].food[0]));
  //var count = JSON.parse(JSON.stringify(specificUserCart[0].food.length));
 //console.log(specificUserCart);
   //console.log(completeMenu)
    // console.log("useerrr: ", specificUserCart);
    for (var i = 0; i < count; i++) {
        // var type = specificUserCart.type;
//console.log(specificUserCart)
        // $.getJSON("http://localhost:3000/menu/food/"+specificUserCart.userMenuId[i], function (menuData) {
        //   console.log(menuData)
        // });
        // var foodItem = JSON.stringify(specificUserCart[0].food[i]);
        // var food = JSON.parse(foodItem)
        // console.log(food)
        //console.log(foodItem)
       // if (specificUserCart.userMenuId == foodItem[i].id) {
           // var food = foodItem[i];
            // console.log(food)
            total += specificUserCart.quantity * food.price.toString();
            // Iterating items in the cart
            // alert("this is matched: ", JSON.stringify(specificUserCart));
            document.getElementById("t-body").innerHTML +=
                "<tr><td class='w-25'><img src='" + food.img + "'" +
                "class='img-fluid img-thumbnail' alt=''></td>" +
                "<td>" + food.name + "</td><td>₹" + (food.price).toString()+ "</td>" +
                "<td class='qty'><input type='text' style='width: 30px;' class='text-center' id='quantityInput" + specificUserCart.id + "' value=" + specificUserCart.quantity + "></td>" +
                "<td>₹" + (specificUserCart.quantity * food.price) + "</td>" +
                "<td><button type='button' class='btn btn-primary' onclick='updateCartIem(" + specificUserCart.id + ")' >Update</button>  </td> " +
                "<td><a href='#' class='btn btn-danger btn-sm'>" +
                " <i class='fa fa-times' onclick='removeItem(" + food.id + ")' id=" + food.id + "></i></a></td>" +
                "</tr>";
       // }
        document.getElementById("cart-total").innerHTML = "₹" + total;


    }
}
function updateCartIem(cartId) {
    const specificQuantityInput = "quantityInput" + cartId;
    let currentQuantity = document.getElementById(specificQuantityInput).value;
    const numCurrentQuantity = Number(currentQuantity);
    if (currentQuantity > 0) {

        // alert(numCurrentQuantity);
        $.ajax({
            type: "PATCH",
            // url: "http://localhost:3000/users// +userId{`cart`}" ,
            url: "http://localhost:3000/userCart/" + cartId,
            data: {
                quantity: numCurrentQuantity
            },
            dataType: "json",
            success: function () {
                alert("Quantity updated.");
            }
        });
    } else {
        alert("To remove item click on cross icon.")
    }
    // alert(quantityInput);
}


function removeItem(menuItemId) {
    // console.log("menu item id: ", menuItemId);
    // alert('deleting cart item of id: ', menuItemId);
    $.ajax({
        type: "DELETE",
        url: "http://localhost:3000/userCart/" + menuItemId,
        dataType: "json",
        success: function () {
            alert('user cart updated');
        }
    });
    //will fetch the id from session storage
    // var id = sessionStorage.getItem("userId")    ;

    const userId = sessionStorage.getItem("userid");
    $.getJSON("http://localhost:3000/users/" + userId, function (userData) {
        removeSpecificItemFromUserData(userData, menuItemId, userId);
    });
}

function removeSpecificItemFromUserData(userData, menuItemId, userId) {

    //below line removing the specific food item from the card
    userData.cart = userData.cart.filter(item => Number(item) !== Number(menuItemId));
    let userD = userData;
    $.ajax({
        type: "put",
        // url: "http://localhost:3000/users// +userId{`cart`}" ,
        url: "http://localhost:3000/users/" + userId,
        data: userD,
        dataType: "json",
        success: function () {
            alert('Cart updated');
            // do what you want on success.
        }
    });
}