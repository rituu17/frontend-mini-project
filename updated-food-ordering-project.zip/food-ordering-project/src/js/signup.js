
// $(document).ready(function () {
//     $("button").click(function () {
//         var name = $("#name").val();
//         var email = $('#email').val();
//         var phone_no = $('#phone_no').val();
//         var newPassword = $('#newPassword').val();
//         var confirmPassword = $('#confirmPassword').val();

//         let record = {
//             "name": name,
//             "email": email,
//             "password": newPassword,
//             "mobile": phone_no,
//             "cart": [],
//             "favourites": []
//         }

//         if (newPassword === confirmPassword) {
//             console.log("record: ", record);
//             $.ajax({
//                 url: "http://localhost:3000/users",
//                 type: "post",
//                 data: record,
//                 dataType: 'JSON',
//                 success: function (userDataResponse) {
//                     sessionStorage.setItem("userid", userDataResponse.id)
//                     // console.log("this is res: ", userDataResponse);
//                     $('form').submit();
//                 },
//                 error: function () {
//                     alert("getting error");
//                 }
//             }).done(function (data) {
//                 alert("Data Loaded: " + data);
//             });
//         } else {
//             alert("Password Mismatch");
//         }

//     });

// });

$(document).ready(function () {

    $("button").click(function () {

        const name = $("#name").val();
        const email = $('#email').val();
        const newPassword = $('#newPassword').val();
        const confirmPassword = $('#confirmPassword').val();
        const phone_no = $('#phone_no').val();
        let record = {
            "name": name,
            "email": email,
            "phone": phone_no,
            "password": newPassword,
        }
        if (email !== "" && newPassword !== "" && confirmPassword !== "" && name != "" && phone_no != "") {
            if (email.includes("@gmail.com") || email.includes("@cybage.com")) {
                if (newPassword === confirmPassword) {
                    $.ajax({
                        url: " http://localhost:3000/users",
                        type: "post",
                        data: record,
                        dataType: 'JSON',
                        success: function () {
                            sessionStorage.setItem("userid", userDataResponse.id)
                            $('form').submit();
                        },
                        error: function () {
                            alert("getting error");
                        }
                    });
                } else {
                    alert("Password Mismatch");
                }
            } else {
                setTimeout(() => {
                    $('#emailType').html("<br><b>Please enter valid email</b><br><br>");
                }, 1000);
            }
        } else {
            alert("Fill all fields")
        }
    });

});








