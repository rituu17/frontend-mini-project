package com.cybage.hcs;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.jni.User;

import com.cybage.modal.Users;
import com.cybage.service.HCSService;
import com.cybage.service.HCSServiceImpl;

/**
 * Servlet implementation class RegisterPatient
 */
@WebServlet("/registerPatient")
public class RegisterPatient extends HttpServlet {

	HCSService service = new HCSServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		boolean success = false;
		Users user = new Users();
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String email = request.getParameter("email");
//		String mobile = request.getParameter("mobile");
//		String password = request.getParameter("password");
//		String address = request.getParameter("address");
//		String city = request.getParameter("city");
		user.setFirstname(request.getParameter("firstName"));
		user.setLastname(request.getParameter("lastName"));
		user.setMobile(Integer.parseInt(request.getParameter("mobile")));
		user.setPassword(request.getParameter("password"));
		user.setCity(request.getParameter("city"));
		user.setEmail( request.getParameter("email"));
		success = service.registerPatient(user);
		if (success) {
			RequestDispatcher d = request.getRequestDispatcher("/LoginUser");
			d.forward(request, response);
		} else {
			doGet(request, response);

		}

	}

}
