package com.cybage.hcs;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.utility.JDBCUtility;

/**
 * Servlet implementation class UpdateProfile
 */
@WebServlet("/UpdateProfile")
public class UpdateProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProfile() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		public boolean updatePatient(Patient patient) {
//			int no=0;
//			try (Connection connection = JDBCUtility.getConnection();) {
//
//				
//				String updateQuery = "update users set firstName=?,lastName=?,email=?,mobile=?,password=?,city=?";
//				PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
//
//				 preparedStatement.setString(1, patient.getFirstName());
//	            		preparedStatement.setString(2, patient.getLastName());
//	            		preparedStatement.setString(3, patient.getEmail());
//	            		preparedStatement.setInt(4, patient.getMobile());
//	            		preparedStatement.setString(5, patient.getPassword());
//	            		preparedStatement.setString(6, patient.getCity() );
//
//				no = preparedStatement.executeUpdate();
//				System.out.println("Number of rows affected: " + no);
//				if (no > 0) {
//					System.out.println("PRofile updated successfully");
//				} else {
//					System.out.println("Some error");
//				}
//
//			} catch (Exception e) {
//				e.printStackTrace();
//			} finally {
//				JDBCUtility.closeConnection();
//			}
//			if (no >0) {
//				return true;
//			} else {
//				return false;
//			}
//		doGet(request, response);
	}

}
