package com.cybage.service;

import java.sql.SQLException;
import java.util.List;
import com.cybage.dao.HCSDAO;
import com.cybage.dao.HCSDAOImpl;
import com.cybage.modal.AllUsers;
import com.cybage.modal.Appointment;
import com.cybage.modal.DetailedAppointment;
import com.cybage.modal.Doctor;
import com.cybage.modal.Roles;
import com.cybage.modal.Specialization;
import com.cybage.modal.Users;

public class HCSServiceImpl implements HCSService {

	HCSDAO adminDAO = new HCSDAOImpl();

	@Override
	public List<Roles> getAllRoles() {
		return adminDAO.getAllRoles();
	}
	
	@Override
	public List<Users> getSpecificUsers(String typeOfUser) {
		return adminDAO.getSpecificUsers(typeOfUser);
	}

	@Override
	public boolean registerDoctor(Users user, String[] doctorsSpecialization) throws ClassNotFoundException, SQLException {
		return adminDAO.registerDoctor(user, doctorsSpecialization);
	}

	@Override
	public List<Specialization> getAllSpecialization() {
		return adminDAO.getAllSpecialization();
	}

	@Override
	public List<AllUsers> getAllUsers() {
		return adminDAO.getAllUsers();
	}

	@Override
	public List<String> getDoctorsSpecializations(int doctordId) {
		return adminDAO. getDoctorsSpecializations(doctordId);
	}

	@Override
	public Users loginUser(String email, String password) {
		return adminDAO.loginUser(email, password);
	}

	@Override
	public List<DetailedAppointment> getALlDetailedAppointments(int roleId, int userId) {
		return adminDAO.getALlDetailedAppointments(roleId, userId);
	}

	@Override
	public boolean updateAppointmentStatus(int appointmentId, String status) {
		return adminDAO.updateAppointmentStatus(appointmentId, status);
	}

	@Override
	public boolean registerPatient(Users user) {
		return adminDAO.registerPatient(user);
	}

	@Override
	public List<Doctor> getSpecializedDoctor(int specializationId) {
		return adminDAO.getSpecializedDoctor(specializationId);
	}

	@Override
	public List<Appointment> getDoctorsAppointment(int doctorId) {
		return adminDAO.getDoctorsAppointment(doctorId);
	}

	@Override
	public boolean addAppointment(Appointment appointment) {
		return adminDAO.addAppointment(appointment);
	}

	@Override
	public Users getUserById(int userId) {
		return adminDAO.getUserById(userId);
	}
	


}
