
$(document).ready(function () {

    $("#login-button").click(function () {
        $('#msg').html("");
        var email = $('#email').val();

        var password = $('#password').val();

        $.getJSON("http://localhost:3000/users",
            function (data) {
                $.each(data,
                    function (_key, userData) {
                        if (userData.email ===
                            email && userData.password ===
                            password && document.getElementById("email").userData !== ""
                            && document.getElementById("password").userData !== "") {
                            // user matched
                            sessionStorage.setItem("userid", userData.id);
                            $('form').submit();
                            window.location.href = "index.html";
                        }
                        else
                            if (email === "admin@cybage.com" && password === "admin") {
                                sessionStorage.setItem("userid", "AdminID")
                                // window.open("../HTML/admin.html");
                            }
                            else
                                if (document.getElementById("email").userData == "") {
                                    alert("Please Enter Email");
                                }
                                else
                                    if (document.getElementById("password").userData == "") {
                                        alert("Please Enter password")
                                    }
                                    else {
                                        setTimeout(() => {
                                            $('#msg').html("<b>Wrong Crentials</b><br><br>");
                                        }, 1000)
                                    }
                    });
            });

    });
});
