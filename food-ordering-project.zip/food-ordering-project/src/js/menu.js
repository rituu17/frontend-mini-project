$(document).ready(function() {
    fetchData();
    function fetchData() {
        $.getJSON("http://localhost:3001/menu",
            function(data) {
                for(let j=0; j<data[0].food.length; j++){
                  $('#burgers').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>"+
                  "<div class='col-md-3 food-image'><img src='../"+data[0].food[j].img+"'></div><div class='col-md-9'"+
                  "><h3 class='food-title'><span class='food-name'>"+data[0].food[j].name+"</span><span class='food-price float-right'>Rs."
                  +data[0].food[j].price+"</span></h3><p class='food-ingredients'>"+data[0].food[j].description+"</p></div>");
                }

                for(let j=0; j<data[1].desserts.length; j++){
                    $('#dessert').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>"+
                    "<div class='col-md-3 food-image'><img src='../"+data[1].desserts[j].img+"'></div><div class='col-md-9'"+
                    "><h3 class='food-title'><span class='food-name'>"+data[1].desserts[j].name+"</span><span class='food-price float-right'>Rs."
                    +data[1].desserts[j].price+"</span></h3><p class='food-ingredients'>"+data[1].desserts[j].description+"</p></div>");
                }


                for(let j=0; j<data[2].drinks.length; j++){
                    $('#drink').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>"+
                    "<div class='col-md-3 food-image'><img src='../"+data[2].drinks[j].img+"'></div><div class='col-md-9'"+
                    "><h3 class='food-title'><span class='food-name'>"+data[2].drinks[j].name+"</span><span class='food-price float-right'>Rs."
                    +data[2].drinks[j].price+"</span></h3><p class='food-ingredients'>"+data[2].drinks[j].description+"</p></div>");
                }
        });
    }
});
