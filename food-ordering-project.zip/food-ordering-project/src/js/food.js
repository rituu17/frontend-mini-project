$(document).ready(function () {

    fetchData();


});
function addToCart(specificFoodItem) {
    var userid = sessionStorage.getItem("userid");
    if (!userid) {
        window.location.href = "../pages/login.html"
    }
    else {
        updateUserCart(specificFoodItem);
    }
}

function updateUserCart(specificFoodItem) {
    const userCartUrl = "http://localhost:3000/userCart";
    const addCartItem = {
        type: "food",
        quantity: 1,
        userMenuId: Number(specificFoodItem.id)
    };
    $.ajax({
        url: userCartUrl,
        type: "post",
        data: addCartItem,
        dataType: 'JSON',
        success: function (userCartResponse) {
        },
        error: function () {
        }

    }).then(function (userRes){
        fetchUserDataaa(userRes.id);
    });


}

function fetchUserDataaa(userCartID) {
    const userId = sessionStorage.getItem("userid");

    let userD;
    $.getJSON("http://localhost:3000/users/" + userId, function (userData) {
        if (userData) {
            updateUserDataaa(userData, userCartID);
        }
    });

}
function updateUserDataaa(userData, userCartID) {
    const updateUserCartStringValue = userData.cart + "," + userCartID;
    $.ajax({
        type: "PATCH",
        url: "http://localhost:3000/users/" + userData.id,
        data: {
            cart: updateUserCartStringValue
        },
        dataType: "json",
        success: function () {
            // do what you want on success.
        }
    });
}

function fetchData() {
    $.getJSON("http://localhost:3000/menu",
        function (data) {
            const foodItems = data[0];
            for (let j = 0; j < foodItems.food.length; j++) {
                let specificFoodItem = foodItems.food[j];
                $('#burgers').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>" +
                    "<div class='col-md-3 food-image'><img height='200px'  width='300px' src='" + specificFoodItem.img + "'></div><div class='col-md-9'" +
                    "><h3 class='food-title'><span class='food-name'>" + specificFoodItem.name + "</span><span class='food-price float-right'>Rs."
                    + specificFoodItem.price + "</span></h3><p class='food-ingredients'>" + specificFoodItem.description + "</p>" +
                    "<a class='btn btn-outline-success float-end' id='login-btn' onclick='addToCart(" + JSON.stringify(specificFoodItem) +
                    ")'  role='button'>Add to Cart</a>" +
                    "</div>");
            }

            for (let j = 0; j < data[1].desserts.length; j++) {
                $('#dessert').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>" +
                    "<div class='col-md-3 food-image'><img src='" + data[1].desserts[j].img + "'></div><div class='col-md-9'" +
                    "><h3 class='food-title'><span class='food-name'>" + data[1].desserts[j].name + "</span><span class='food-price float-right'>Rs."
                    + data[1].desserts[j].price + "</span></h3><p class='food-ingredients'>" + data[1].desserts[j].description + "</p></div>");
            }


            for (let j = 0; j < data[2].drinks.length; j++) {
                $('#drink').append("<hr class='food-horizontal-rule'><div class='row align-items-center menu-item'>" +
                    "<div class='col-md-3 food-image'><img src='" + data[2].drinks[j].img + "'></div><div class='col-md-9'" +
                    "><h3 class='food-title'><span class='food-name'>" + data[2].drinks[j].name + "</span><span class='food-price float-right'>Rs."
                    + data[2].drinks[j].price + "</span></h3><p class='food-ingredients'>" + data[2].drinks[j].description + "</p></div>");
            }
        });
}
