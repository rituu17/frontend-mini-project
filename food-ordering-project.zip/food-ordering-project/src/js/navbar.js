

// function showCartModal(){
//     alert("somethinggg");


// }





$(document).ready(function () {

    const userId = sessionStorage.getItem("userid");
    // console.log("this is user id: ", userId);
    if(userId == null){
        // alert("user not found");
        // show login and sign up button
        $("#user-login").show();
        $("#show-cart-title").hide();
        $("#show-profile").hide();
        $("#logout-btn").hide();
        
    }else{
        // alert("user found");
          // show user profile
          $("#show-cart-title").show();
          $("#show-profile").show();
          $("#logout-btn").show();
          $("#user-login").hide();
    }


});
function logoutUser(){
    window.location.href = "index.html"
    sessionStorage.clear();
}

