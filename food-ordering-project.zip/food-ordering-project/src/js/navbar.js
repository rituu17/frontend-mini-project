

// function showCartModal(){
//     alert("somethinggg");


// }





$(document).ready(function () {

    // $("#cart-modal").click(function () {
        
    // });



    const userId = sessionStorage.getItem("userid");
    // console.log("this is user id: ", userId);
    if(userId == null){
        // alert("user not found");
        // show login and sign up button
        $("#user-login").show();
        $("#show-cart-title").hide();
        $("#show-profile").hide();
        
    }else{
        // alert("user found");
          // show user profile
          $("#show-cart-title").show();
          $("#show-profile").show();
          $("#user-login").hide();
    }


});

// function iterateCartModal() {
//     // alert("something");
//     $.getJSON("http://localhost:3000/users/1", function (data) {
//         var cartItem = data.cart;
//         fetchCartItem(cartItem);
//     });
// }

