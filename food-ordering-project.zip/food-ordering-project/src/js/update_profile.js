$(document).ready(function () {
    const userId = sessionStorage.getItem("userid");
    fetchUserData(userId);
});


function fetchUserData(userId) {
    $.getJSON("http://localhost:3000/users/" + userId, function (data) {
        // var cartItem = data.cart;
        showUserProfile(data);
    });
}
function showUserProfile(userData) {
  

    $("#username-title").html(userData.name);
    $("#username").val(userData.name);
    $("#username").prop("disabled", true);

    $("#userEmailId").val(userData.email);
    $("#userEmailId").prop("disabled", true);
    
    $("#userPhone").val(userData.mobile);
    $("#userPhone").prop("disabled", true);
}