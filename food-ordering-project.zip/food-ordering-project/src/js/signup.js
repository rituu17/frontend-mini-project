
$(document).ready(function () {

    $("button").click(function () {

        var name = $("#name").val();
        var email = $('#email').val();
        var phone_no = $('#phone_no').val();
        var newPassword = $('#newPassword').val();
        var confirmPassword = $('#confirmPassword').val();
        let record = {
            "name": name,
            "email": email,
            "password": newPassword,
            "mobile": phone_no,
            "cart": [],
            "favourites": []
        }

        if (newPassword === confirmPassword) {
            console.log("record: ", record);
            $.ajax({
                url: "http://localhost:3000/users",
                type: "post",
                data: record,
                dataType: 'JSON',
                success: function () {
                    $('form').submit();
                },
                error: function () {
                    alert("getting error");
                }
            });

        } else {

            alert("Password Mismatch");
        }

    });

});




