function validateEmail() {

    // get value of input email 

    var email = $("#email").val();

    // use reular expression 

    var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
    if (reg.test(email)) {

        return true;

    } else {
        return false;
    }
}
function validateNewPassword() {
    var password = $("#newPassword").val();
    var regExFroPassword = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (regExFroPassword.test(password)) {
        $("#newPassword").css("border", "2px solid green");
        return true;
    } else {
        $("#newPassword").css("border", "2px solid red");
        return false;
    }

}

function validateConfirmPassword() {
    var password = $("#confirmPassword").val();
    var regExFroPassword = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (regExFroPassword.test(password)) {
        $("#confirmPassword").css("border", "2px solid green");
        return true;
    } else {
        $("#confirmPassword").css("border", "2px solid red");
        return false;
    }
}

$(document).ready(function () {
    $("#email").keyup(function () {
        if (validateEmail()) {
            $("#email").css("border", "2px solid green");
        } else {
            // if the email is not validated 
            // set border red 
            $("#email").css("border", "2px solid red");
        }
    });
    $("button").click(function () {

        const name = $("#name").val();
        const email = $('#email').val();
        const newPassword = $('#newPassword').val();
        const confirmPassword = $('#confirmPassword').val();
        const phone_no = $('#phone_no').val();
        let record = {
            "name": name,
            "email": email,
            "phone": phone_no,
            "password": newPassword,
        }
        if (email !== "" && newPassword !== "" && confirmPassword !== "" && name != "" && phone_no != "") {
            if (email.includes("@") || email.includes(".com")) {
                if (newPassword === confirmPassword) {
                    if (validateEmail() && validateConfirmPassword() && validateNewPassword()) {
                        $.ajax({
                            url: " http://localhost:3000/users",
                            type: "post",
                            data: record,
                            dataType: 'JSON',
                            success: function () {
                                sessionStorage.setItem("userid", userDataResponse.id)
                                window.location.href = "index.html";
                                $('form').submit();
                            },
                            error: function () {
                                alert("getting error");
                            }
                        });
                    }
                    else {
                        alert("Enter valid input");
                    }
                } else {
                    alert("Password Mismatch");
                }
            } else {
                setTimeout(() => {
                    $('#emailType').html("<br><b>Please enter valid email</b><br><br>");

                }, 1000);
                alert("email");
            }
        } else {
            alert("Fill all fields")
        }
    });

});








