// document.getElementById("cart-modal").click(showCartModal());
var foodItemsAdded = false;
// document.getElementById("cart-modal").click(fetchUserData())

function showCartModal() {
    // alert("something");
    $.getJSON("http://localhost:3000/users/1", function (data) {
        var cartItem = data.cart;
        fetchCartItem(cartItem);

    });
}


function fetchCartItem(cartItem) {
    console.log(cartItem)
    // if (cartItem[].length > 0) {
        var menu;
        var usersCart;
        $.getJSON("http://localhost:3000/menu", function (menuData) {
            menu = menuData;
            console.log("this is menu: ", menu);
            something(cartItem, menu);
        });

    // }
}
function something(cartItem, menu) {
    $.getJSON("http://localhost:3000/userCart", function (userCart) {
        // console.log("this is user cart: ", userCart);
        updateCart(cartItem, menu, userCart);
    });
}

function updateCart(cartItem, menu, userCart) {
    // console.log("cartItem: ", cartItem)
    // for (var i = 0; i < cartItem.length; i++) {
        // const cartItems = "cartItem[]";
        var specificCartId = cartItem[i];
        fetchCartItems(specificCartId, userCart, menu);
    // }
}
function fetchCartItems(specificCartId, userCart, menu) {
    // console.log("this is menu: ", menu);
    for (var i = 0; i < userCart.length; i++) {
        if (specificCartId == userCart[i].id) {
            // 
            type = userCart[i].type;
            quantity = userCart[i].quantity;
            console.log(" type: ", menu, " quantity: ", quantity);
            addFood(userCart[i], menu);
        }
    }
}


function addFood(specificUserCart, completeMenu) {
    for (var i = 0; i < completeMenu.length; i++) {
        // var type = specificUserCart.type;
        var foodItem = completeMenu[0].food;
        if (specificUserCart.userMenuId == foodItem[i].id) {
            console.log("this is matched: ", foodItem[i].name);
            var food = foodItem[i];
            // Iterating items in the cart
            document.getElementById("t-body").innerHTML +=
                "<tr><td class='w-25'><img src='media/album/album-desserts@4x.jpg'" +
                "class='img-fluid img-thumbnail' alt=''></td><td>" +
                food.name + "</td><td>₹" + (food.price).toString() + "</td>" +
                "<td class='qty'><input type='text' class='form-control text-center' id='input1' value=" + quantity + "></td>" +
                "<td>₹" + (quantity * food.price) + "</td> <td><a href='#' class='btn btn-danger btn-sm'>" +
                "<i class='fa fa-times' onclick='removeItem(" + food.id + ")' id=" + food.id + "></i></a></td></tr>";
        }

    }
}


function removeItem(menuItemId) {
    // console.log("menu item id: ", menuItemId);
    // alert('deleting cart item of id: ', menuItemId);
    $.ajax({
        type: "DELETE",
        url: "http://localhost:3000/userCart/" + menuItemId,
        dataType: "json",
        success: function () {
            alert('user cart updated');
        }
    });
    //will fetch the id from session storage
    // var id = sessionStorage.getItem("userId")    ;


    $.getJSON("http://localhost:3000/users/1", function (userData) {
        removeSpecificItemFromUserData(userData, menuItemId);
    });
}

function removeSpecificItemFromUserData(userData, menuItemId) {
    console.log("user data: ", userData);
    console.log("menu data: ", menuItemId);


    //below line removing the specific food item from the card
    userData.cart = userData.cart.filter(item => Number(item) !== Number(menuItemId));


    // console.log("this should be deleted from cart: ", userData.cart);
    alert(JSON.stringify(userData.cart));
    console.log("update user data: ", userData);
    alert(JSON.stringify(userData));
    let userD = userData;
    //  returnRemainingItem(userData.cart);


    $.ajax({
        type: "put",
        // url: "http://localhost:3000/users/1/{`cart`}" ,
        url: "http://localhost:3000/users/1",
        data: userD,

        // JSON.stringify(userData),
        //  {
        //     id: userData.id,
        //     name: userData.name,
        //     email: userData.email,
        //     password: userData.password,
        //     mobile: userData.mobile,
        //     cart: userData.cart,
        //     favourites: userData.favourites
        // },

        dataType: "json",
        success: function () {
            alert('cart updated');
            // do what you want on success.
        }
    });
}
function returnRemainingItem(cart) {
    var record = [];
    var item = {};
    for (var i = 0; i < cart.length; i++) {
        item = {
            "id": cart[i].id,
            "type": cart[i].type,
            "quantity": cart[i].quantity
        }
        record.push(item);
    }
    // console.log("this is updated cart: ",record);
    return record;

}

  //     cartItem = [1,2,3];
    //     userCart=[
    //         {
    //     },
    //     {
    //     },
    //     {

    //     }
    // ];
    //     menu = {[
    //         food:[{
    //         },
    //         {
    //         }
    //     ]
    //     ]}
