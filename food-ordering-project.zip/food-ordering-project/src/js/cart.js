function showCartModal() {
    const userId = sessionStorage.getItem("userid");
    $.getJSON("http://localhost:3000/users/" + userId, function (data) {
        const cartItem = data.cart;
        // if cart is undefined then dont call the fetCartItem() method

        if (!cartItem) {
            //cart item is undefined means users dont have items in his cart
            hideCartDetails();

        } else {
            const cartArray = cartItem.split(",");
                fetchCartItem(cartArray);
                $("#empty-cart-image").hide();
        }
    });
}

function hideCartDetails() {
    $("#cart-headings").hide();
    $("#total-text").hide();
    $("#checkout-btn").hide();
    $("#empty-cart-image").show();
    $("#cart-modal-heading").html("Your Food cart is empty");
}

function fetchCartItem(cartItem) {

    if (cartItem) {
        $.getJSON("http://localhost:3000/menu", function (menuData) {
            menu = menuData;
            fetchCompleteCartObject(cartItem, menu);
            document.getElementById("t-body").innerHTML = "";
        });
    }
}
function fetchCompleteCartObject(cartItem, menu) {
    $.getJSON("http://localhost:3000/userCart", function (userCart) {
        updateCart(cartItem, menu, userCart);
    });
}

function updateCart(cartItem, menu, userCart) {


    for (var i = 0; i < cartItem.length; i++) {
        
        var specificCartId = cartItem[i];
        if(specificCartId != "0")
            fetchCartItems(specificCartId, userCart, menu);
    }
}
function fetchCartItems(specificCartId, userCart, menu) {
    for (var i = 0; i < userCart.length; i++) {
        if (Number(specificCartId) == userCart[i].id) {
            type = userCart[i].type;
            quantity = userCart[i].quantity;
            addFood(userCart[i], menu);
        }
    }
}

var total = 0;
function addFood(specificUserCart, completeMenu) {

    const foodItem = completeMenu[0].food;
    const completeMenuLength = completeMenu[0].food.length;
    for (var i = 0; i < completeMenuLength; i++) {
        const foodId = (foodItem[i].id).toString();
        if (specificUserCart.userMenuId == foodId) {
            var food = foodItem[i];
            total += specificUserCart.quantity * food.price;
            // Iterating items in the cart
            document.getElementById("t-body").innerHTML +=
                "<tr><td class='w-25'><img src='" + food.img + "'" +
                "class='img-fluid img-thumbnail' alt=''></td>" +
                "<td>" + food.name + "</td><td>₹" + (food.price).toString() + "</td>" +
                "<td class='qty'><input type='text' style='width: 30px;' class='text-center' id='quantityInput" + specificUserCart.id + "' value=" + specificUserCart.quantity + "></td>" +
                "<td>₹" + (specificUserCart.quantity * food.price) + "</td>" +
                "<td><button type='button' class='btn btn-primary' onclick='updateCartIem(" + specificUserCart.id + ")' >Update</button>  </td> " +
                "<td><a href='#' class='btn btn-danger btn-sm'>" +
                " <i class='fa fa-times' onclick='removeItem(" + specificUserCart.id + ")' id=" + specificUserCart.id + "></i></a></td>" +
                "</tr>";
        }
        document.getElementById("cart-total").innerHTML = "₹" + total;


    }
}
function updateCartIem(cartId) {
    const specificQuantityInput = "quantityInput" + cartId;
    let currentQuantity = document.getElementById(specificQuantityInput).value;
    const numCurrentQuantity = Number(currentQuantity);
    if (currentQuantity > 0) {

        $.ajax({
            type: "PATCH",
            url: "http://localhost:3000/userCart/" + cartId,
            data: {
                quantity: numCurrentQuantity
            },
            dataType: "json",
            success: function () {
            }
        });
    } else {
    }
}


function removeItem(menuItemId) {
    $.ajax({
        type: "DELETE",
        url: "http://localhost:3000/userCart/" + menuItemId,
        dataType: "json",
        
    });
    const userId = sessionStorage.getItem("userid");
    removeSpecificItemFromUserData(menuItemId, userId);
    //will fetch the id from session storage


}

function removeSpecificItemFromUserData(menuItemId, userId) {
    $.getJSON("http://localhost:3000/users/" + userId, function (userData) {
        let cartString = "";
        menuItemId = Number(menuItemId);
        let userCartArray = userData.cart.split(",");
        let numUserCartArray = [];
        for (var i = 0; i < userCartArray.length; i++) {
            numUserCartArray.push(Number(userCartArray[i]));
        }
        const array = numUserCartArray;
        const index = array.indexOf(menuItemId);
        if (index > -1) {
            array.splice(index, 1);
        }
        // array = [2, 9] 
        for (var i = 0; i < array.length; i++) {
            cartString += array[i] + ",";
        }
        updateUserCartStringValue(userId, cartString);

    });

    //below line removing the specific food item from the card


}
function updateUserCartStringValue(userId, cartString) {
    $.ajax({
        type: "PATCH",
        url: "http://localhost:3000/users/" + userId,
        data: {
            cart: cartString
        },
        dataType: "json",
        success: function () {
            
        }
    });
}