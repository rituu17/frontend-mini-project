function showCartModal() {
    const userId = sessionStorage.getItem("userid");
    $.getJSON("http://localhost:3000/users/" + userId, function (data) {
        var cartItem = data.cart;
        // if cart is undefined then dont call the fetCartItem() method

        if (!cartItem) {
            //cart item is undefined means users dont have items in his cart
            hideCartDetails();

        } else {
            // user has some items in his cart;
            $("#empty-cart-image").hide();
            fetchCartItem(cartItem);
        }
    });
}

function hideCartDetails() {

    $("#cart-headings").hide();
    $("#total-text").hide();
    $("#checkout-btn").hide();
    $("#empty-cart-image").show();
    $("#cart-modal-heading").html("Your Food cart is empty");






}

function fetchCartItem(cartItem) {

    // if (cartItem[].length > 0) {
    if (cartItem) {


        var menu;
        var usersCart;
        $.getJSON("http://localhost:3000/menu", function (menuData) {
            menu = menuData;
            // console.log("this is menu: ", menu);
            fetchCompleteCartObject(cartItem, menu);
            document.getElementById("t-body").innerHTML = "";

        });
    }
    // }
}
function fetchCompleteCartObject(cartItem, menu) {
    // alert(12);
    $.getJSON("http://localhost:3000/userCart", function (userCart) {
        // console.log("this is user cart: ", userCart);
        // if(!cartItem){
        updateCart(cartItem, menu, userCart);
        // }else{
        // alert("your cart is empty");
        // }
    });
}

function updateCart(cartItem, menu, userCart) {
    // console.log("cartItem: ", cartItem)

    for (var i = 0; i < cartItem.length; i++) {
        // const cartItems = "cartItem[]";
        var specificCartId = cartItem[i];
        fetchCartItems(specificCartId, userCart, menu);
    }
}
function fetchCartItems(specificCartId, userCart, menu) {
    // console.log("this is menu: ", menu);
    for (var i = 0; i < userCart.length; i++) {
        if (specificCartId == userCart[i].id) {
            // 
            type = userCart[i].type;
            quantity = userCart[i].quantity;
            // console.log(" type: ", menu, " quantity: ", quantity);
            addFood(userCart[i], menu);
        }
    }
}

var total = 0;
function addFood(specificUserCart, completeMenu) {
    // console.log("useerrr: ", specificUserCart);
    for (var i = 0; i < completeMenu.length; i++) {
        // var type = specificUserCart.type;
        var foodItem = completeMenu[0].food;
        if (specificUserCart.userMenuId == foodItem[i].id) {
            var food = foodItem[i];
            total += specificUserCart.quantity * food.price;
            // Iterating items in the cart
            // alert("this is matched: ", JSON.stringify(specificUserCart));
            document.getElementById("t-body").innerHTML +=
                "<tr><td class='w-25'><img src='" + food.img + "'" +
                "class='img-fluid img-thumbnail' alt=''></td>" +
                "<td>" + food.name + "</td><td>₹" + (food.price).toString() + "</td>" +
                "<td class='qty'><input type='text' style='width: 30px;' class='text-center' id='quantityInput" + specificUserCart.id + "' value=" + specificUserCart.quantity + "></td>" +
                "<td>₹" + (specificUserCart.quantity * food.price) + "</td>" +
                "<td><button type='button' class='btn btn-primary' onclick='updateCartIem(" + specificUserCart.id + ")' >Update</button>  </td> " +
                "<td><a href='#' class='btn btn-danger btn-sm'>" +
                " <i class='fa fa-times' onclick='removeItem(" + food.id + ")' id=" + food.id + "></i></a></td>" +
                "</tr>";
        }
        document.getElementById("cart-total").innerHTML = "₹@@" + total;


    }
}
function updateCartIem(cartId) {
    const specificQuantityInput = "quantityInput" + cartId;
    let currentQuantity = document.getElementById(specificQuantityInput).value;
    const numCurrentQuantity = Number(currentQuantity);
    if (currentQuantity > 0) {

        // alert(numCurrentQuantity);
        $.ajax({
            type: "PATCH",
            // url: "http://localhost:3000/users// +userId{`cart`}" ,
            url: "http://localhost:3000/userCart/" + cartId,
            data: {
                quantity: numCurrentQuantity
            },
            dataType: "json",
            success: function () {
                alert("Quantity updated.");
            }
        });
    } else {
        alert("To remove item click on cross icon.")
    }
    // alert(quantityInput);
}


function removeItem(menuItemId) {
    // console.log("menu item id: ", menuItemId);
    // alert('deleting cart item of id: ', menuItemId);
    $.ajax({
        type: "DELETE",
        url: "http://localhost:3000/userCart/" + menuItemId,
        dataType: "json",
        success: function () {
            alert('user cart updated');
        }
    });
    //will fetch the id from session storage
    // var id = sessionStorage.getItem("userId")    ;

    const userId = sessionStorage.getItem("userid");
    $.getJSON("http://localhost:3000/users/" + userId, function (userData) {
        removeSpecificItemFromUserData(userData, menuItemId, userId);
    });
}

function removeSpecificItemFromUserData(userData, menuItemId, userId) {

    //below line removing the specific food item from the card
    userData.cart = userData.cart.filter(item => Number(item) !== Number(menuItemId));
    let userD = userData;
    $.ajax({
        type: "put",
        // url: "http://localhost:3000/users// +userId{`cart`}" ,
        url: "http://localhost:3000/users/" + userId,
        data: userD,
        dataType: "json",
        success: function () {
            alert('Cart updated');
            // do what you want on success.
        }
    });
}