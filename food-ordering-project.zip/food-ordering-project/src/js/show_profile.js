$(document).ready(function(){
    const userId = sessionStorage.getItem("userid");
    fetchUserData(userId);
});


function fetchUserData(userId){
        $.getJSON("http://localhost:3000/users/" + userId, function (data) {
        // var cartItem = data.cart;
        showUserProfile(data);
    });
}
function showUserProfile(userData){
    // if((userData.profilepic).length > 0){
    //     $("#userProfilePic").attr('src', userData.profilepic);
    // }
    // console.log("user data from profile page: ",userData);
    $("#username-title").html(userData.name);
    $("#username").html(userData.name);
    $("#userEmailId").html(userData.email);
    $("#userPhone").html(userData.mobile);
}