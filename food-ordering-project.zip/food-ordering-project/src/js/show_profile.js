$(document).ready(function(){
    const userId = sessionStorage.getItem("userid");
    fetchUserData(userId);
});


function fetchUserData(userId){
        $.getJSON("http://localhost:3000/users/" + userId, function (data) {
        // var cartItem = data.cart;
        showUserProfile(data);
    });
}
function showUserProfile(userData){
    $("#username-title").html(userData.name);
    $("#username").html(userData.name);
    $("#userEmailId").html(userData.email);
    $("#userPhone").html(userData.mobile);
}