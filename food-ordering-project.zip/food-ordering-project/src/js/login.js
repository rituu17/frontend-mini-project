function validateEmail() {
    // get value of input email 
    var email = $("#email").val();
    // use reular expression 
    var reg = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
    if (reg.test(email)) {
        return true;
    } else {
        return false;
    }
}
function validatePassword() {
    var password = $("#password").val();
    var regExFroPassword = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (regExFroPassword.test(password)) {
        return true;
    } else {
        return false;
    }

}




$(document).ready(function () {
  $("#email").keyup(function () {
        if (validateEmail()) {
            $("#email").css("border", "2px solid green");
        } else {
            // if the email is not validated 
            // set border red 
            $("#email").css("border", "2px solid red");
        }
    });
    $("#newPassword").keyup(function () {
        if (validatePassword()) {
            $("#password").css("border", "2px solid green");
        } else {
            // if the password is not validated 
            // set border red 
            $("#password").css("border", "2px solid red");
        }
    });
    $("#login-button").click(function () {
        $('#msg').html("");
        var email = $('#email').val();
        var password = $('#password').val();
        $.getJSON("http://localhost:3000/users",
            function (data) {
                $.each(data,
                    function (_key, userData) {
                        if (userData.email === email && userData.password ===
                            password && document.getElementById("email").userData !== ""
                            && document.getElementById("password").userData !== "") {
                            // user matched
                            sessionStorage.setItem("userid", userData.id);
                            $('form').submit();
                            window.location.href = "index.html";
                        }
                        else {
                            if (document.getElementById("email").userData == "") {
                                alert("Please Enter Email");
                            }
                            else {
                                if (document.getElementById("password").userData == "") {
                                    alert("Please Enter password")
                                }
                                else {
                                    setTimeout(() => {
                                        $('#msg').html("<b class='text-danger'>Wrong Crentials</b><br><br>");
                                    }, 1000)
                                }
                            }
                        }
                    });
            });

    });
});
