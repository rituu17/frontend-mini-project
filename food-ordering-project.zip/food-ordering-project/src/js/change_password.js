function fetchPassword() {
    const userId = sessionStorage.getItem("userid");
    const newPassword = document.getElementById("newPassword").value;
    const newPasswordRepeat = document.getElementById("newPasswordRepeat").value;
    // if (newPassword === newPasswordRepeat) {
    $.ajax({
        type: "GET",
        url: "http://localhost:3000/users/" + userId ,
        // url: "http://localhost:3000/users/" + userId,
        dataType: 'json',
        success: function (userData, textStatus, xhr) {
            changePassword(userData, newPassword)
        },
        error: function (xhr, textStatus, errorThrown) {
            // console.log('Could not update passowrd.');
        }
    });
}
function changePassword(userData, newPassword) {
    // alert(3);
    $.ajax({
        type: "PATCH",
        url: "http://localhost:3000/users/" + userData.id,
        data: {
            password: newPassword
        },
        dataType: "json",
        success: function () {
            alert("Password updated.");
            window.location.href = "index.html";
            $('form').submit();
        },
        error: function (xhr, textStatus, errorThrown) {
            alert("Could not update password.");
        }
    });
}