package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.Appointment;
import com.cybage.bean.Doctor;
import com.cybage.dao.AppointmentDao;
import com.cybage.dao.DoctorDao;
import com.cybage.utility.JDBCUtility;

/**
 * Servlet implementation class PatientServlet
 */
@WebServlet("/PatientServlet")
public class PatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();

		Doctor d = (Doctor) session.getAttribute("doctObj");
		System.out.println("id : " + d.getId());
		AppointmentDao dao = null;
		try {
			dao = new AppointmentDao(JDBCUtility.getConnection());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		List<Appointment> list = dao.getAllAppointmentByDoctorLogin(d.getId());
		session.setAttribute("list", list);
		response.sendRedirect("doctor/patient.jsp");
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
