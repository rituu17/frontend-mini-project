package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.constants.ConstantVars;
import com.cybage.model.PatientComplaints;
import com.cybage.service.PatientComplaintsService;

@RestController
@RequestMapping("/patients-complaints")
@CrossOrigin
public class PatientComplaintsController {

	@Autowired
	PatientComplaintsService patientComplaintsService;
	
	@GetMapping("/get-all")
	public ResponseEntity<List<PatientComplaints>> getAllUsers() {
		List<PatientComplaints> allComplaints = patientComplaintsService.getAllComplaints();
		return new ResponseEntity<List<PatientComplaints>>(allComplaints , HttpStatus.OK);
	}

//	patientComplaintsId
	@GetMapping("/get-complaint-by-id/{patientComplaintsId}")
	public ResponseEntity<PatientComplaints> getPatientComplaintsIdById(@PathVariable Long patientComplaintsId) {
		PatientComplaints complaint = patientComplaintsService.getComplaintById(patientComplaintsId);
		return new ResponseEntity<PatientComplaints>(complaint, HttpStatus.OK);
	}
	
	@GetMapping("/complaint-by-patient-id/{patientId}")
	public ResponseEntity<List<PatientComplaints>> getPatientComplaintsIdPatientById(@PathVariable Long patientId) {
		List<PatientComplaints> complaints = patientComplaintsService.getComplaintsPatientById(patientId);
		return new ResponseEntity<List<PatientComplaints>>(complaints, HttpStatus.OK);
	}
	
	@GetMapping("/send-reminder/{patientComplaintsId}")
	public ResponseEntity<String> sendReminder(@PathVariable Long patientComplaintsId) {
		boolean isReminderSend= patientComplaintsService.sendReminder(patientComplaintsId);
		if(isReminderSend)
			return new ResponseEntity<String>(ConstantVars.COMPLAINT_REMINDER_SENT_SUCCESSFULLY, HttpStatus.OK);
		else
			return new ResponseEntity<String>(ConstantVars.COMPLAINT_REMINDER_SENT_FAILED, HttpStatus.BAD_REQUEST);
	}
	
	@PostMapping("/add-complaint")
	public ResponseEntity<String> addComplint(@RequestBody PatientComplaints patientComplaints) {
		boolean isComplaintAdded = patientComplaintsService.addComplaint(patientComplaints);
		if (isComplaintAdded)
			return new ResponseEntity<String>(ConstantVars.COMPLAINT_REGISTERED_SUCCESSFULLY, HttpStatus.CREATED);
		else
			return new ResponseEntity<String>(ConstantVars.COMPLAINT_REGISTERATION_FAILED, HttpStatus.BAD_REQUEST);
	}
	
	@PutMapping("/update-complaint/{patientComplaintsId}")
	public ResponseEntity<String> updateUser(@RequestBody PatientComplaints complaint, @PathVariable Long patientComplaintsId) {
		boolean isComplaintUpdated = patientComplaintsService.updateComplaint(complaint, patientComplaintsId);
		if (isComplaintUpdated)
			return new ResponseEntity<String>(ConstantVars.COMPLAINT_UPDATED_SUCCESSFULLY, HttpStatus.CREATED);
		else
			return new ResponseEntity<String>(ConstantVars.COMPLAINT_UPDATION_FAILED, HttpStatus.BAD_REQUEST);
	}
	
	
	
	

}
