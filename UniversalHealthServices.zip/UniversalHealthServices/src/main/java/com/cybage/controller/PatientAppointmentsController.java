package com.cybage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.model.PatientsAppointments;
import com.cybage.service.PatientAppointmentsService;

@RestController
@RequestMapping("/appointments")
@CrossOrigin
public class PatientAppointmentsController {

	@Autowired
	PatientAppointmentsService patientAppointmentsService;

	@GetMapping("/get-all")
	public ResponseEntity<List<PatientsAppointments>> getAllAppointments() {
		List<PatientsAppointments> allAppointments = patientAppointmentsService.getAllPaitientsAppointments();
		return new ResponseEntity<List<PatientsAppointments>>(allAppointments, HttpStatus.OK);
	}

	@PostMapping("/add-appointment")
	public ResponseEntity<String> addAppointment(@RequestBody PatientsAppointments patientsAppointments) {
		String appointmentReponse = patientAppointmentsService.addAppointment(patientsAppointments);
		return new ResponseEntity<String>(appointmentReponse, HttpStatus.BAD_REQUEST);
	}

	@PutMapping("/update-appointment/{appointmentId}")
	public ResponseEntity<String> updateAppointment(@RequestBody PatientsAppointments patientsAppointments,
			@PathVariable Long appointmentId) {
		String updateAppointmentReponse = patientAppointmentsService.updateAppointment(patientsAppointments,
				appointmentId);
		return new ResponseEntity<String>(updateAppointmentReponse, HttpStatus.BAD_REQUEST);
	}

	@GetMapping("/change-status/{appointmentId}/{status}")
	public ResponseEntity<String> changeAppointmentStatus(@PathVariable Long appointmentId,
			@PathVariable String status) {
		String appointmentStatusResponse = patientAppointmentsService.changeAppointmentStatus(appointmentId, status);
		return new ResponseEntity<String>(appointmentStatusResponse, HttpStatus.OK);
	}

}
