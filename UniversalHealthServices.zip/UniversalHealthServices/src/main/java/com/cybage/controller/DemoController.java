package com.cybage.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/products")
@CrossOrigin
public class DemoController {
//	@Autowired
//	NewProductService productService;

	@GetMapping("/hello")
//	@ResponseBody   we can remove this annotation after replacing @Controller with @ResController
	public String hello() {
		return "something from the hello mapping";
	}
//
//	@GetMapping("/getProductById/{id}")
//	public ResponseEntity<NewProduct> getProductsById(@PathVariable String id) {
//		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
//		headers.add("headerkey1", "headerValue1");
////		Class<? extends Object> dataType = ;
//		boolean isInt = false;
//		try {
//			Integer.parseInt(id);
//			isInt = true;
//		} catch (NumberFormatException e) {
//			isInt = false;
//		}
//		NewProduct product = new NewProduct();
//		if (isInt) {
//			product = productService.getProductById(Integer.parseInt(id));
//			if (product == null)
//				throw new RecordException("Product not found");
//		} else {
//			throw new InvalidInput("Invalid input");
//		}
//		return new ResponseEntity<NewProduct>(product, headers, HttpStatus.OK);
//	}
//
//	@GetMapping("/getProductByName/{name}")
//	public ResponseEntity<NewProduct> getProductsByName(@PathVariable String name) {
//		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
//		headers.add("headerkey1", "headerValue1");
//		return new ResponseEntity<NewProduct>(headers, HttpStatus.OK);
//	}
//
//	@PostMapping("/add")
//	public ResponseEntity<String> addProduct(@RequestBody NewProduct product) {
//		boolean isProductAdded = productService.addProduct(product);
//		if (isProductAdded)
//			return new ResponseEntity<String>("Productt added successfully.", HttpStatus.CREATED);
//		else
//			return new ResponseEntity<String>("Some error.", HttpStatus.BAD_REQUEST);
//	}
//
//	@GetMapping("/delete/{id}")
//	public ResponseEntity<String> deleteProductById(@PathVariable int id) {
////		NewProduct product = productService.getProductById(id);
////		boolean isProductDeleted =
//				productService.deleteProductById(id);
////		if (isProductDeleted)
//			return new ResponseEntity<String>("Product deleted successfully.", HttpStatus.CREATED);
////		else
////			return new ResponseEntity<String>("Some error.", HttpStatus.BAD_REQUEST);
//	}
//
//	@PutMapping("/update")
//	public ResponseEntity<String> updateProductById(@RequestBody NewProduct product) {
////		boolean isProductUpdated = productService.updateProduct(product);
////		if (isProductUpdated)
//			return new ResponseEntity<String>("Product updated successfully.", HttpStatus.CREATED);
////		else
////			return new ResponseEntity<String>("Some error.", HttpStatus.BAD_REQUEST);
//	}
//
//	@GetMapping("/show")
//	public ResponseEntity<List<NewProduct>> getAllProducts() {
//		List<NewProduct> allProducts = productService.getAllProducts();
//		return new ResponseEntity<List<NewProduct>>(allProducts, HttpStatus.OK);
//	}

//	@ExceptionHandler(RecordException.class)
//	public ResponseEntity<String> handleException(RecordException exception) {
//		return new ResponseEntity<String>(exception.getMessage(), HttpStatus.NOT_FOUND);
//	}

}
