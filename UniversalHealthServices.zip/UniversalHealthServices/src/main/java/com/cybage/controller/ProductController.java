package com.cybage.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.exception.InvalidInput;
import com.cybage.exception.RecordException;

@RestController
@RequestMapping("/product")
@CrossOrigin
public class ProductController {
//
//	@Autowired
//	ProductService productService;
//
//	@PostMapping("/add")
//	public ResponseEntity<String> addProduct(@RequestBody OldProduct product) {
//
//		System.out.println("working");
//		boolean success = productService.addProduct(product);
//		if (success)
//			return new ResponseEntity<String>("Product added succcessfully.", HttpStatus.CREATED);
//		else
//			return new ResponseEntity<String>("Product could not be added.", HttpStatus.BAD_REQUEST);
//	}
//
//	@GetMapping("/getAll")
//	public ResponseEntity<List<OldProduct>> getAllProducts() {
//		List<OldProduct> products = productService.getAllProducts();
//		return new ResponseEntity<List<OldProduct>>(products, HttpStatus.CREATED);
//	}
//
//	@GetMapping("/get/{id}")
//	public ResponseEntity<OldProduct> getById(@PathVariable String id) {
//		boolean isInt = false;
//		try {
//			Integer.parseInt(id);
//			isInt = true;
//		} catch (NumberFormatException e) {
//			isInt = false;
//		}
//		OldProduct product = null;
//		if (isInt) {
//			product = productService.getProductById(Integer.parseInt(id));
//			if (product == null)
//				throw new RecordException("Product not found");
//		} else {
//			throw new InvalidInput("Invalid input");
//		}
//		return new ResponseEntity<OldProduct>(product, HttpStatus.CREATED);
//	}
//	
//	@GetMapping("/byName/{name}")
//	public ResponseEntity<List<OldProduct>> getByName(@PathVariable String name) {
//		List<OldProduct> products = new ArrayList<OldProduct>();
//			products = productService.getProductByName(name);
//			if (products.size() == 0)
//				throw new RecordException("No products of name " + name);
//		return new ResponseEntity<List<OldProduct>>(products, HttpStatus.CREATED);
//	}
//	
//	@GetMapping("/byNameQuery/{name}")
//	public ResponseEntity<List<OldProduct>> getByNameQuery(@PathVariable String name) {
//		List<OldProduct> products = new ArrayList<OldProduct>();
//			products = productService.getProductByNameQuery(name);
//			if (products.size() == 0)
//				throw new RecordException("No products of name " + name);
//		return new ResponseEntity<List<OldProduct>>(products, HttpStatus.CREATED);
//	}
//
//	@GetMapping("/byId/{id}")
//	public ResponseEntity<OldProduct> getByIdNativeQuery(@PathVariable int id) {
//		OldProduct product ;
//		product = productService.getById(id);
//		return new ResponseEntity<OldProduct>(product, HttpStatus.CREATED);
//	}
//	
//	@GetMapping("/get/{noOfRows}")
//	public ResponseEntity<List<OldProduct>> getSomeProduct(@PathVariable String noOfRows) {
//		boolean isInt = false;
//		try {
//			Integer.parseInt(noOfRows);
//			isInt = true;
//		} catch (NumberFormatException e) {
//			isInt = false;
//		}
//		List<OldProduct> products = new ArrayList<OldProduct>();
//		if (isInt) {
//			products = productService.getSomeProducts(Integer.parseInt(noOfRows));
//			if (products.size() == 0)
//				throw new RecordException("No products found");
//		} else {
//			throw new InvalidInput("Invalid input");
//		}
//		return new ResponseEntity<List<OldProduct>>(products, HttpStatus.CREATED);
//	}
//	
//
//	
//	@PutMapping("/update/{id}")
//	public ResponseEntity<String> updateProduct(@PathVariable String id, @RequestBody OldProduct product) {
//		boolean isInt = false;
//		try {
//			Integer.parseInt(id);
//			isInt = true;
//		} catch (NumberFormatException e) {
//			isInt = false;
//		}
//		OldProduct updatedProduct;
//		if (isInt) {
//			updatedProduct = productService.updateProduct(Integer.parseInt(id), product);
//			if (updatedProduct != null)
//				return new ResponseEntity<String>("Product updated succcessfully.", HttpStatus.ACCEPTED);
//			else
//				return new ResponseEntity<String>("Product could not be updated.", HttpStatus.BAD_REQUEST);
//		} else {
//			throw new InvalidInput("Invalid input");
//		}
//		
//	}
//	
//	
//	@DeleteMapping("/delete/{id}")
//	public ResponseEntity<String> deleteById(@PathVariable String id) {
//		boolean isInt = false;
//		try {
//			Integer.parseInt(id);
//			isInt = true;
//		} catch (NumberFormatException e) {
//			isInt = false;
//		}
//		if (isInt) {
//			productService.deleteProductById(Integer.parseInt(id));
//			return new ResponseEntity<String>("Product deleted succcessfully.", HttpStatus.CREATED);
//		} else {
//			throw new InvalidInput("Invalid input");
//		}
//	}

}
