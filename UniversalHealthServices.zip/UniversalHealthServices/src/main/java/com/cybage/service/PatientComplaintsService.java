package com.cybage.service;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cybage.constants.ConstantVars;
import com.cybage.model.PatientComplaints;
import com.cybage.model.Users;
import com.cybage.model.UsersAccountStatusEntity;
import com.cybage.repository.PatientsComplaintsRepository;
import com.cybage.repository.UsersAccountStatusRepository;
import com.cybage.repository.UsersRepository;

@Service
public class PatientComplaintsService {

	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private PatientsComplaintsRepository patientComplaintsRepository;
	@Autowired
	private UsersAccountStatusRepository usersAccountStatusRepository;

	public List<PatientComplaints> getAllComplaints() {
		return patientComplaintsRepository.findAll();
	}

	public PatientComplaints getComplaintById(Long patientComplaintsId) {
		PatientComplaints complaint = patientComplaintsRepository
				.findPatientComplaintsByPatientComplaintsId(patientComplaintsId);
		return complaint;
	}

	public boolean updateComplaint(PatientComplaints complaint, Long patientComplaintsId) {
		complaint.setPatientComplaintsId(patientComplaintsId);
		complaint.setComplaintStatus(ConstantVars.COMPLAINT_STATUS.RESOLVED.toString());
		PatientComplaints patientComplaints = patientComplaintsRepository.save(complaint);
		Users user = usersRepository.findUsersByUsersId(complaint.getPatientId());
		return sendUpdatedComplaintDetailsOnMail(patientComplaints, user);
	}

	public boolean addComplaint(PatientComplaints patientComplaints) {
		patientComplaints.setComplaintStatus(ConstantVars.COMPLAINT_STATUS.PENDING.toString());
		patientComplaints.setCreatedTime(new Timestamp(new Date().getTime()));
		patientComplaints.setReminderSent(0);
		PatientComplaints newPatientComplaints = patientComplaintsRepository.save(patientComplaints);
		Users patientsDetails = usersRepository.findUsersByUsersId(newPatientComplaints.getPatientId());
		return sendComplaintDetailsOnMail(newPatientComplaints, patientsDetails);
	}

	private boolean sendComplaintDetailsOnMail(PatientComplaints complaint, Users user) {
		String toAddress = user.getEmail();
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Complaint Details Update";
		Date complaintRegisterdDate = complaint.getCreatedTime();
		
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi " + user.getFirstname() + " " + user.getLastname()
				+ "		,</p>"
				+ "    <p>Your complaint has been resolved. "
				+ " 	We are sorry for the inconvenience.</p>"
				+ "    <p> Please find below the updates on your complaint:</p>"
				+ "		Description: " + complaint.getComplaintDescription()  + "</br>"
				+ "		Type: " + complaint.getComplaintType() + "</br> "
				+ "		Status: " + complaint.getComplaintStatus() + "</br> "
				+ "		Created on: " + complaintRegisterdDate  
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return false;
		} catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}

		mailSender.send(message);
		return true;
	}
	
	private boolean sendUpdatedComplaintDetailsOnMail(PatientComplaints complaint, Users user) {
		String toAddress = user.getEmail();
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Complaint Details";
		Date complaintRegisterdDate = complaint.getCreatedTime();
		
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi " + user.getFirstname() + " " + user.getLastname()
				+ "		,</p>"
				+ "    <p> Your complaint has been created. We will send you updates on your email."
				+ " 	We are sorry for the inconvenience.</p>"
				+ "    <p> Please find below your complaint's details:</p>"
				+ "		Description: " + complaint.getComplaintDescription()  + "</br>"
				+ "		Type: " + complaint.getComplaintType() + "</br> "
				+ "		Updated Status: " + complaint.getComplaintStatus() + "</br> "
				+ "		Response: " + complaint.getAdminReply() + "</br> "
				+ "		Created on: " + complaintRegisterdDate  
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return false;
		} catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}

		mailSender.send(message);
		return true;
	}

	public List<PatientComplaints> getComplaintsPatientById(Long patientId) {
		return patientComplaintsRepository.findPatientComplaintsByPatientId(patientId);
	}

	public boolean sendReminder(Long patientComplaintsId) {
		PatientComplaints complaint =
				patientComplaintsRepository.findPatientComplaintsByPatientComplaintsId(patientComplaintsId);
		Users user = usersRepository.findUsersByUsersId(complaint.getPatientId());
		UsersAccountStatusEntity userAccountStatus =
				usersAccountStatusRepository.findUsersAccountStatusEntityByUsersAccountStatusId(user.getAccountStatus());
//		Date date = new Date();
//		Date complaintCreatedDate = complaint.getCreatedTime();
//		if(date - complaintCreatedDate >=5)
		String toAddress = "chaitanyadeshm@cybage.com";
		String fromAddress = "Trng2@evolvingsols.com";
		String senderName = "Universal Health Services";
		String subject = "Complaint's Reminder";
		Date complaintRegisterdDate = complaint.getCreatedTime();
		
		String newContent = " <div style='font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2'>"
				+ "  <div style='margin:50px auto;width:70%;padding:20px 0'>"
				+ "    <div style='border-bottom:1px solid #eee'>"
				+ "      <a href='' style='font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600'>Universal Health Services</a>"
				+ "    </div>  <p style='font-size:1.1em'>Hi Admin,</p>"
				+ "    <p>The below complaint is not yet resolved yet:</p>"
				+ "		Full Name: " + user.getFirstname() + " " + user.getLastname()  + "</br>"
				+ "		Email: " + user.getEmail() + "</br>"
				+ "		Contact no.: " + user.getMobile() + "</br>"
				+ "		User's current account status.: " + userAccountStatus.getStatus() + "</br>"
				+ "		Description: " + complaint.getComplaintDescription()  + "</br>"
				+ "		Type: " + complaint.getComplaintType() + "</br> "
				+ "		Status: " + complaint.getComplaintStatus() + "</br> "
				+ "		Created on: " + complaintRegisterdDate  
				+ "     <br/> <p style='font-size:0.9em;'>Regards,<br/>Your UHS</p>"
				+ "    <hr style='border:none;border-top:1px solid #eee' />"
				+ "    <div style='float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>"
				+ "      <p>Universal Health Services Inc.</p>   <p>1600 Amphitheatre Parkway</p> <p>Pune</p>"
				+ "    </div> </div>	";
		MimeMessage message = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);

		try {
			helper.setFrom(fromAddress, senderName);
			helper.setTo(toAddress);
			helper.setSubject(subject);
			helper.setText(newContent, true);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return false;
		} catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}

		mailSender.send(message);
		return true;
	}

}
