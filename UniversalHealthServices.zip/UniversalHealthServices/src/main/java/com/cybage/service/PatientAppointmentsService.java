package com.cybage.service;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.constants.ConstantVars;
import com.cybage.model.PatientsAppointments;
import com.cybage.repository.PatientApointmentsRepository;

@Service
public class PatientAppointmentsService {

	@Autowired
	private PatientApointmentsRepository patientApointmentsRepository;

	public List<PatientsAppointments> getAllPaitientsAppointments() {
		return patientApointmentsRepository.findAll();
	}

	public String addAppointment(PatientsAppointments patientsAppointments) {
		patientsAppointments.setAppointmentStatus(ConstantVars.APPONTMENT_STATUS.PENDING.toString());
		patientsAppointments.setCreatedTime(new Timestamp(new Date().getTime()));
		PatientsAppointments newCreatedAppointment = patientApointmentsRepository.save(patientsAppointments);
		if (newCreatedAppointment.getAppointmentId() > 0) {
			return ConstantVars.APPOINTMENT_ADDED_SUCCESSFULLY;
		} else {
			return ConstantVars.APPOINTMENT_ADDED_FAILED;
		}
	}

	public String changeAppointmentStatus(Long appointmentId, String newStatus) {
		PatientsAppointments patientsAppointments = patientApointmentsRepository
				.findPatientsAppointmentsByAppointmentId(appointmentId);
		if (patientsAppointments != null) {
			return ConstantVars.APPOINTMENT_STATUS_UPDATED_SUCCESSFULLY;
		} else {
			return ConstantVars.APPOINTMENT_IVALID_ID;
		}
	}

	public String updateAppointment(PatientsAppointments patientsAppointments, Long appointmentId) {
		patientsAppointments.setAppointmentId(appointmentId);
		PatientsAppointments updatedPatientsAppointments = patientApointmentsRepository.save(patientsAppointments);
		if (updatedPatientsAppointments != null) {
			return ConstantVars.APPOINTMENT_STATUS_UPDATED_SUCCESSFULLY;
		} else {
			return ConstantVars.APPOINTMENT_IVALID_ID;
		}

//		return null;
	}

	public PatientsAppointments getPatientsAppointmentById(Long appointmentId) {
		
		
		
		
		
		
		return null;
	}

}
