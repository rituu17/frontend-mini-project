package com.cybage.service;

import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cybage.constants.ConstantMethods;
import com.cybage.constants.ConstantVars;
import com.cybage.model.Doctor;
import com.cybage.model.DoctorsSpecialization;
import com.cybage.model.Users;
import com.cybage.repository.DoctorsSpecializationRepository;
import com.cybage.repository.UsersRepository;

@Service
public class DoctorsSpecializationService {

	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private DoctorsSpecializationRepository doctorsSpecializationRepository;
	
//	public List<Users> getAllDoctorsAccordingToSpecialization() {
//		return null;
////		List<Users> allUsers = usersRepository.findAll();
////		return allUsers;
//	}



}
