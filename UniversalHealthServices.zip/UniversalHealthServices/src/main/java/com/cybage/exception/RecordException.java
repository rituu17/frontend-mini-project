package com.cybage.exception;

public class RecordException extends RuntimeException{
	public RecordException(String msg) {
		super(msg);
	}
}
