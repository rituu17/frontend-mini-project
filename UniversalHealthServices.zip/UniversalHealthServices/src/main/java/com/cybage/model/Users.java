package com.cybage.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class Users {
	@Id // this will be primary key in DB
	@GeneratedValue // auto increment
	@Column(name = "usersId")
	private Long usersId;

	@Column(name = "userTypes")
	private int usersRoleId;

	@Column(name = "firstname")
	private String firstname;
	
	@Column(name = "lastname")
	private String lastname;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "accountStatus")
	private int accountStatus;
	
	@Column(name = "usersProfileUrl")
	private String usersProfileUrl;
	
	@Column(name = "mobile")
	private String mobile;
	
	@Column(name = "loginAttempts")
	private Integer loginAttempts;
	
	@Column(name = "accountCreated")
	private Timestamp accountCreated;
	
	@Column(name = "usersOTP")
	private Integer usersOTP;


	public Users(int usersRoleId, String firstname, String lastname, String email, String usersProfileUrl,
			String mobile) {
		super();
		this.usersRoleId = usersRoleId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.usersProfileUrl = usersProfileUrl;
		this.mobile = mobile;
	}
	
	

}
