package com.cybage.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name="users_account_status")
public class UsersAccountStatusEntity {
	@Id // this will be primary key in DB
	@GeneratedValue // auto increment
	@Column(name = "usersAccountStatusId")
	private Integer usersAccountStatusId;

	@Column(name = "status")
	private String status;	

}
