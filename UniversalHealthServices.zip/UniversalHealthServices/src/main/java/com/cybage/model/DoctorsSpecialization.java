package com.cybage.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.UniqueElements;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class DoctorsSpecialization {
	@Id // this will be primary key in DB
	@GeneratedValue // auto increment
	@Column(name = "doctorsSpecializationId")
	private int doctorsSpecializationId;


	@Column(name = "specializationId")
	private int specializationId;
	
	@Column(name = "doctorId")
	private Long doctorId;

	public DoctorsSpecialization(int specializationId, Long doctorId) {
		super();
		this.specializationId = specializationId;
		this.doctorId = doctorId;
	}

	// constructor for storing the specialization against a specific doctor id without sending the ID value of the table

	
	
}
