package com.cybage.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class Specialization {
	@Id // this will be primary key in DB
	@GeneratedValue // auto increment
	@Column(name = "specializationId")
	private int specializationId;

	@Column(name = "category")
	private String category;

}
