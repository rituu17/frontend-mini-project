package com.cybage.model;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class PatientsAppointments {
	
	
	@Id // this will be primary key in DB
	@GeneratedValue // auto increment
	@Column(name = "appointment_id")
	private int appointmentId;
	
	@Column(name = "patientId")
	private int patientId;
	
	@Column(name="doctorId")
	private int doctorId;
	
	@Column(name="appointmentDate")
	private Date appointmentDate;
	
	@Column(name="appointmentTime")
	private Time appointmentTime;
	
	@Column(name="prescription")
	private String prescription;
	
	@Column(name="patientsNotes")
	private String patientsNotes;
	
	@Column(name="appointmentStatus")
	private String appointmentStatus;
	
	@Column(name="doctorsRatings")
	private int doctorsRatings;
	
	
	@Column(name="feedback")
	private String feedback;


}
