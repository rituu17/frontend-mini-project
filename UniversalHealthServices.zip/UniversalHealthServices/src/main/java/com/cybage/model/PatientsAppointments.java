package com.cybage.model;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Entity
public class PatientsAppointments {

	@Id // this will be primary key in DB
	@GeneratedValue // auto increment
	@Column(name = "appointment_id")
	private Long appointmentId;
	
	@Column(name = "patientId")
	private Long patientId;
	
	@Column(name="doctorId")
	private Long doctorId;
	
	@Column(name="appointmentDate")
	private Date appointmentDate;
	
	@Column(name="appointmentTime")
	private Time appointmentTime;
	
	@Column(name="prescription")
	private String prescription;
	
	@Column(name="patientsNotes")
	private String patientsNotes;
	
	@Column(name="appointmentStatus")
	private String appointmentStatus;
	
	@Column(name="doctorsRatings")
	private Integer doctorsRatings;
	
	@Column(name="feedback")
	private String feedback;
	
	@Column(name = "created_time")
	private Timestamp createdTime;

	public PatientsAppointments(Long patientId, Long doctorId, Date appointmentDate, Time appointmentTime,
			String patientsNotes, String appointmentStatus) {
		super();
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.patientsNotes = patientsNotes;
		this.appointmentStatus = appointmentStatus;
	}

	public PatientsAppointments(Long patientId, Long doctorId, Date appointmentDate, Time appointmentTime,
			String prescription, String patientsNotes, String appointmentStatus, Integer doctorsRatings,
			String feedback, Timestamp createdTime) {
		super();
		this.patientId = patientId;
		this.doctorId = doctorId;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.prescription = prescription;
		this.patientsNotes = patientsNotes;
		this.appointmentStatus = appointmentStatus;
		this.doctorsRatings = doctorsRatings;
		this.feedback = feedback;
		this.createdTime = createdTime;
	}
	
	
	
	


}
