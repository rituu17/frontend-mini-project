package com.cybage.model;

import java.sql.Timestamp;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Doctor {
	private Long usersId;

	private int usersRoleId;

	private String firstname;
	
	private String lastname;
	
	private String email;
	
	private int accountStatus;
	
	private String usersProfileUrl;
	
	private String mobile;
	
	private Integer loginAttempts;
	
	private Timestamp accountCreated;
	
	private Integer usersOTP;
	private List<Integer> specializationsId;



	
	

}
