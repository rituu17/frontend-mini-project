package com.cybage.constants;


public class ConstantVars {

	public static final String ADMIN_EMAIL = "admin@cybage.com";

	public static final int OTP_LENGTH = 6; 
	public static final int MAX_LOGIN_ATTEMPTS_ALLOWED= 3; 
	
	public static enum ACCOUNT_STATUS { 
		   ACTTIVE, INACTIVE, BLOCKED, BLOCKED_BY_ADMIN, DELETED 
	};
	
	public static enum APPONTMENT_STATUS { 
		   PENDING, APPROVE, REJECTED, DONE  
	};
	public static enum COMPLAINT_STATUS { 
		   PENDING, RESOLVED
	};
	
	
	public static final String COMPLAINT_REGISTERED_SUCCESSFULLY = "Your complaint created successfully.\nComplaint details has been sent to your email.";
	public static final String COMPLAINT_REGISTERATION_FAILED = "Could not create complaint. Try again later or write email to " + ADMIN_EMAIL;
	public static final String COMPLAINT_UPDATION_FAILED = "Could not update complaint.\nTry again later or write email to " + ADMIN_EMAIL;
	public static final String COMPLAINT_UPDATED_SUCCESSFULLY = "Complaint updated successfully.";
	public static final String COMPLAINT_REMINDER_SENT_SUCCESSFULLY = "Reminder for your complaint has been sent successfully.";
	public static final String COMPLAINT_REMINDER_SENT_FAILED = "Could not send reminder.\nTry again later or write email to " + ADMIN_EMAIL;

	
	
	
	
	
	public static final String USER_REGISTERED_SUCCESSFULLY = "Your account created successfully.\nVerification link has been sent to your email.";
	public static final String USER_ALREADY_REGISTERED_WITH_THIS_ACCOUNT = "Email already registered.\nTry logging in.";
	public static final String USER_REGISTERATION_FAILED = "Could not create account. Try again later or write email to " + ADMIN_EMAIL;

	public static final String DOCTOR_REGISTERED_SUCCESSFULLY = "Doctor registered successfully.\nCredentials has been sent to his email.";
	public static final String DOCTOR_REGISTERED_FAILED = "Could not register doctor.\nTry again later";
	
	
	
	public static final String ERROR_RESPONSE = "Something went wrong.\nWrite email to admin@cybage.com";
	public static final String USER_DELETED_SUCCESS = "Your account has been deleted successfully.";
	public static final String USER_DELETED_FAILED = "Your account had been already deleted.";
	public static final String USER_UPDATED_FAILED = "Could not update user.\nTry again later.";
	public static final String USER_UPDATED_SUCCESSFULLY = "User updated successfully.";
	public static final String USER_NOT_FOUND = "No user is registered with this email./nTry registering to our application.";
	public static final String OTP_SENT_SUCCESSFULLY = "OTP has been sent successfully to your registerd email.";
	
	public static final String VERIFY_ACCOUNT_BEFORE_LOGIN = "Your account is not verified yet.\nCheck your email for verification link.";
	public static final String ACCOUNT_BLOCKED = "Your account is blocked.\nTry contacting admin at admin@cybage.com";
	public static final String ACCOUNT_BLOCKED_BY_ADMIN = "Your account has been blocked by admin.\nTry contacting admin at admin@cybage.com";
	public static final String ACCOUNT_DELETED = "Your account is deleted.\nCreate new account to use this application.";
	public static final String OTP_VERIFIED_SUCCESSFULLY = "OTP verified successfully.";
	public static final String WRONG_OTP_ENTERED = "You have entered wrong OTP.";
	public static final String MAX_OTP_ENTERED_EXCEEDED = "You have entered wrong OTP 3 times.\nYour account has been blocked. Write email to admin@cybage.com";

	public static final String APPOINTMENT_ADDED_SUCCESSFULLY = "Your appointment is booked successfully. \nYou will get further updates on your mail.";
	public static final String APPOINTMENT_ADDED_FAILED = "Could not book your appointment.\nTry again later or you can write email to "
			+ ADMIN_EMAIL;
	public static final String APPOINTMENT_IVALID_ID = "Could not find appointment.\nInvalid appointment Id";
	public static final String APPOINTMENT_STATUS_UPDATED_SUCCESSFULLY = "Appointment updated successfully.";
	
	public static final String SOMETHING_WENT_WRONG = "Something went wrong.\nTry again later or write email to "+ ADMIN_EMAIL;

	
	public static final String EMAIL_VERIFIED_PAGE = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"\r\n" + 
			"<head>\r\n" + 
			"    <title></title>\r\n" + 
			"    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />\r\n" + 
			"    <meta name='viewport' content='width=device-width, initial-scale=1'>\r\n" + 
			"    <meta http-equiv='X-UA-Compatible' content='IE=edge' />\r\n" + 
			"    <style type='text/css'>\r\n" + 
			"        @media screen {\r\n" + 
			"            @font-face {\r\n" + 
			"                font-family: 'Lato';\r\n" + 
			"                font-style: normal;\r\n" + 
			"                font-weight: 400;\r\n" + 
			"                src: local('Lato Regular'), local('Lato-Regular'), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format('woff');\r\n" + 
			"            }\r\n" + 
			"\r\n" + 
			"            @font-face {\r\n" + 
			"                font-family: 'Lato';\r\n" + 
			"                font-style: normal;\r\n" + 
			"                font-weight: 700;\r\n" + 
			"                src: local('Lato Bold'), local('Lato-Bold'), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format('woff');\r\n" + 
			"            }\r\n" + 
			"\r\n" + 
			"            @font-face {\r\n" + 
			"                font-family: 'Lato';\r\n" + 
			"                font-style: italic;\r\n" + 
			"                font-weight: 400;\r\n" + 
			"                src: local('Lato Italic'), local('Lato-Italic'), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format('woff');\r\n" + 
			"            }\r\n" + 
			"\r\n" + 
			"            @font-face {\r\n" + 
			"                font-family: 'Lato';\r\n" + 
			"                font-style: italic;\r\n" + 
			"                font-weight: 700;\r\n" + 
			"                src: local('Lato Bold Italic'), local('Lato-BoldItalic'), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format('woff');\r\n" + 
			"            }\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        /* CLIENT-SPECIFIC STYLES */\r\n" + 
			"        body,\r\n" + 
			"        table,\r\n" + 
			"        td,\r\n" + 
			"        a {\r\n" + 
			"            -webkit-text-size-adjust: 100%;\r\n" + 
			"            -ms-text-size-adjust: 100%;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        table,\r\n" + 
			"        td {\r\n" + 
			"            mso-table-lspace: 0pt;\r\n" + 
			"            mso-table-rspace: 0pt;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        img {\r\n" + 
			"            -ms-interpolation-mode: bicubic;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        /* RESET STYLES */\r\n" + 
			"        img {\r\n" + 
			"            border: 0;\r\n" + 
			"            height: auto;\r\n" + 
			"            line-height: 100%;\r\n" + 
			"            outline: none;\r\n" + 
			"            text-decoration: none;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        table {\r\n" + 
			"            border-collapse: collapse !important;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        body {\r\n" + 
			"            height: 100% !important;\r\n" + 
			"            margin: 0 !important;\r\n" + 
			"            padding: 0 !important;\r\n" + 
			"            width: 100% !important;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        /* iOS BLUE LINKS */\r\n" + 
			"        a[x-apple-data-detectors] {\r\n" + 
			"            color: inherit !important;\r\n" + 
			"            text-decoration: none !important;\r\n" + 
			"            font-size: inherit !important;\r\n" + 
			"            font-family: inherit !important;\r\n" + 
			"            font-weight: inherit !important;\r\n" + 
			"            line-height: inherit !important;\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        /* MOBILE STYLES */\r\n" + 
			"        @media screen and (max-width:600px) {\r\n" + 
			"            h1 {\r\n" + 
			"                font-size: 32px !important;\r\n" + 
			"                line-height: 32px !important;\r\n" + 
			"            }\r\n" + 
			"        }\r\n" + 
			"\r\n" + 
			"        /* ANDROID CENTER FIX */\r\n" + 
			"        div[style*='margin: 16px 0;'] {\r\n" + 
			"            margin: 0 !important;\r\n" + 
			"        }\r\n" + 
			"    </style>\r\n" + 
			"</head>\r\n" + 
			"\r\n" + 
			"<body style='background-color: #f4f4f4; margin: 0 !important; padding: 0 !important;'>\r\n" + 
			"    <!-- HIDDEN PREHEADER TEXT -->\r\n" + 
			"    <div\r\n" + 
			"        style='display: none; font-size: 1px; color: #fefefe; line-height: 1px; font-family:  Lato, Helvetica, Arial, sans-serif; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;'>\r\n" + 
			"    </div>\r\n" + 
			"    <table border='0' cellpadding='0' cellspacing='0' width='100%'>\r\n" + 
			"        <!-- LOGO -->\r\n" + 
			"        <tr>\r\n" + 
			"            <td bgcolor='#73c1d4' align='center'>\r\n" + 
			"                <table border='0' cellpadding='0' cellspacing='0' width='100%' style='max-width: 600px;'>\r\n" + 
			"                    <tr>\r\n" + 
			"                        <td align='center' valign='top' style='padding: 40px 10px 40px 10px;'> </td>\r\n" + 
			"                    </tr>\r\n" + 
			"                </table>\r\n" + 
			"            </td>\r\n" + 
			"        </tr>\r\n" + 
			"        <tr>\r\n" + 
			"            <td bgcolor='#73c1d4' align='center' style='padding: 0px 10px 0px 10px;'>\r\n" + 
			"                <table border='0' cellpadding='0' cellspacing='0' width='100%' style='max-width: 600px;'>\r\n" + 
			"                    <tr>\r\n" + 
			"                        <td bgcolor='#ffffff' align='center' valign='top'\r\n" + 
			"                            style='padding: 40px 20px 20px 20px; border-radius: 10px 10px 0px 0px; color: #111111; font-family: Lato', Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;'>\r\n" + 
			"                            <h1 style='font-size: 48px; font-weight: 400; margin: 2;'>Welcome!</h1> <img\r\n" + 
			"                                src=' https://img.icons8.com/clouds/100/000000/handshake.png' width='125' height='120'\r\n" + 
			"                                style='display: block; border: 0px;' />\r\n" + 
			"                        </td>\r\n" + 
			"                    </tr>\r\n" + 
			"                </table>\r\n" + 
			"            </td>\r\n" + 
			"        </tr>\r\n" + 
			"        <tr>\r\n" + 
			"            <td bgcolor='#f4f4f4' align='center' style='padding: 0px 10px 0px 10px;'>\r\n" + 
			"                <table border='0' cellpadding='0' cellspacing='0' width='100%' style='max-width: 600px;'>\r\n" + 
			"                    <tr>\r\n" + 
			"                        <td bgcolor='#ffffff' align='left'\r\n" + 
			"                            style='padding: 20px 30px 40px 30px; color: #666666; font-family: Lato', Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;'>\r\n" + 
			"                            <p style='margin: 0;'><h2>Your account has been verified successfully.</h2>\r\n" + 
			"                                Use below button to login to your account.</p>\r\n" + 
			"                        </td>\r\n" + 
			"                    </tr>\r\n" + 
			"                    <tr>\r\n" + 
			"                        <td bgcolor='#ffffff' align='left'>\r\n" + 
			"                            <table width='100%' border='0' cellspacing='0' cellpadding='0'>\r\n" + 
			"                                <tr>\r\n" + 
			"                                    <td bgcolor='#ffffff' align='center' style='padding: 20px 30px 60px 30px;'>\r\n" + 
			"                                        <table border='0' cellspacing='0' cellpadding='0'>\r\n" + 
			"                                            <tr>\r\n" + 
			"                                                <td align='center' style='border-radius: 3px;' bgcolor='#73c1d4'><a\r\n" + 
			"                                                        href='#' target='_blank'\r\n" + 
			"                                                        style='font-size: 20px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 15px 25px; border-radius: 10px; border: 1px solid #73c1d4; display: inline-block;'>Login to UHS</a></td>\r\n" + 
			"                                            </tr>\r\n" + 
			"                                        </table>\r\n" + 
			"                                    </td>\r\n" + 
			"                                </tr>\r\n" + 
			"                            </table>\r\n" + 
			"                        </td>\r\n" + 
			"                    </tr> \r\n" + 
			"                    <tr>\r\n" + 
			"                        <td bgcolor='#ffffff' align='left'\r\n" + 
			"                            style='padding: 20px 30px 20px 30px; color: #666666; font-family: Lato, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;'>\r\n" + 
			"                            <p style='margin: 0;'><a href='#' target='_blank'\r\n" + 
			"                                    style='color: #73c1d4;'></a></p>\r\n" + 
			"                        </td>\r\n" + 
			"                    </tr>\r\n" + 
			"                    <tr>\r\n" + 
			"                        <td bgcolor='#ffffff' align='left'\r\n" + 
			"                            style='padding: 0px 30px 20px 30px; color: #666666; font-family: Lato, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;'>\r\n" + 
			"                            <p style='margin: 0;'>If you have any questions, just reply to this email admin@cybage.com we're always\r\n" + 
			"                                happy to help out.</p>\r\n" + 
			"                        </td>\r\n" + 
			"                    </tr>\r\n" + 
			"                    <tr>\r\n" + 
			"                        <td bgcolor='#ffffff' align='left'\r\n" + 
			"                            style='padding: 0px 30px 40px 30px; border-radius: 0px 0px 4px 4px; color: #666666; font-family: Lato, Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;'>\r\n" + 
			"                            <hr style='border:none;border-top:1px solid #eee' />\r\n" + 
			"                            <div\r\n" + 
			"                                style='float:left;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300'>\r\n" + 
			"                                <p  style='margin: 0;'>Universal Health Services Inc.</p>\r\n" + 
			"                                <p  style='margin: 0;'>1600 Amphitheatre Parkway</p>\r\n" + 
			"                                <p  style='margin: 0;'>Pune</p>\r\n" + 
			"                            </div>\r\n" + 
			"                        </td>\r\n" + 
			"                    </tr>\r\n" + 
			"                </table>\r\n" + 
			"            </td>\r\n" + 
			"        </tr>\r\n" + 
			"    </table>\r\n" + 
			"</body>\r\n" + 
			"\r\n" + 
			"</html>";

}
