package com.cybage.constants;

import java.util.Random;

public class ConstantMethods {

	public static int generateOtp() {

		Random randomOTP = new Random();
		char[] otp = new char[ConstantVars.OTP_LENGTH];
		for (int i = 0; i < 6; i++) {
			otp[i] = (char) (randomOTP.nextInt(10) + 48);
		}
		return Integer.parseInt(String.valueOf(otp));

	}

}
