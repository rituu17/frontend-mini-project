package com.cybage.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cybage.register.Registration;

public class patientDAO {
	
	/*
	 * public boolean register(Users user, String[] doctorsSpecialization) {
	 * Connection connection; boolean success = false;
	 */
	
	
	public int register(Registration registration) throws ClassNotFoundException {
        String INSERT_USERS_SQL = "insert into users(role_id, firstname, lastname, email, mobile, password, active, profile_url,city) values(3, ?, ?, ?, ?, ?, 1, null, ?)";

        
        int result = 0;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/miniprojecttwo?useSSL=false", "root", "root");

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            //preparedStatement.setInt(2, 3);
            preparedStatement.setString(1, registration.getFirstName());
            preparedStatement.setString(2, registration.getLastName());
            preparedStatement.setString(3, registration.getEmail());
            preparedStatement.setInt(4, registration.getMobile());
            preparedStatement.setString(5, registration.getPassword());
            //preparedStatement.setInt(8, 1);
            //preparedStatement.setString(9,"null");
            
            preparedStatement.setString(6, registration.getCity() );

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return result;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
	
}
