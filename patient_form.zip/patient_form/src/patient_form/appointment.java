package patient_form;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class appointment {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Loaded");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/miniprojecttwo","root","root");
		System.out.println("conection established");
		java.util.Date date=new java.util.Date();
		java.sql.Date sqlDate=new java.sql.Date(date.getTime());
		java.sql.Timestamp sqlTime=new java.sql.Timestamp(date.getTime());
		PreparedStatement st=con.prepareStatement("insert into appointments values(?,?,?,?,?,?,?,?,?)");
		st.setInt(1,5);
		st.setInt(2,5);
		st.setInt(3,5);
		st.setDate(4,sqlDate);
		st.setTimestamp(5,sqlTime);
		st.setString(6,"Pending");;
		st.setString(7,"good");//feedback
		st.setInt(8,5);
		st.setString(9,"Null");
		int count=st.executeUpdate();
		System.out.println("Number of rows of data inserted :"+" "+count);
	}

}
