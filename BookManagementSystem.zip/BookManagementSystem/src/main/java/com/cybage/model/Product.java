package com.cybage.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class Product {

	@Min(10)
	@Max(1000)
	@NotBlank(message = "{Size.Product.Empty}")
	private Integer productId;
	@NotBlank(message = "{Size.Product.ProductName}")
	private String productName;
	@Min(10)
	@Max(1000)
	@NotBlank(message = "{Size.Product.Empty}")
	private Integer productPrice;
	@Min(1)
	@Max(10)
	@NotBlank(message = "{Size.Product.Empty}")
	private Integer quantity;

	public Product() {
		super();
	}

	public Product(Integer productId, String productName, Integer productPrice, Integer quantity) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.quantity = quantity;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Integer productPrice) {
		this.productPrice = productPrice;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
