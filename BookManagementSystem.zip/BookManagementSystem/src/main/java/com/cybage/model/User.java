package com.cybage.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class User {

	@NotBlank(message = "{Size.Product.Empty}")
	private String userName;
	@NotBlank(message = "{Size.Product.ProductName}")
	private String userEmail;
	@NotBlank(message = "{Size.Product.ProductName}")
	private Integer userMobile;
	@NotBlank(message = "{Size.Product.ProductName}")
	private String userCity;
	@NotBlank(message = "{Size.Product.ProductName}")
	private String userPassword;
	public User() {
		super();
	}
	public User(@NotBlank(message = "{Size.Product.Empty}") String userName,
			@NotBlank(message = "{Size.Product.ProductName}") String userEmail,
			@NotBlank(message = "{Size.Product.ProductName}") Integer userMobile,
			@NotBlank(message = "{Size.Product.ProductName}") String userCity,
			@NotBlank(message = "{Size.Product.ProductName}") String userPassword) {
		super();
		this.userName = userName;
		this.userEmail = userEmail;
		this.userMobile = userMobile;
		this.userCity = userCity;
		this.userPassword = userPassword;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public Integer getUserMobile() {
		return userMobile;
	}
	public void setUserMobile(Integer userMobile) {
		this.userMobile = userMobile;
	}
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

}
