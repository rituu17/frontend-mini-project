package com.cybage.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.model.Book;
import com.cybage.model.Product;
import com.cybage.model.User;
import com.cybage.service.BookService;
import com.cybage.service.ProductService;

@Controller
public class BookController {

	@Autowired
	ProductService productService;
	@Autowired
	BookService bookService;
	
	@GetMapping("/test")
	@ResponseBody
	public String test() {
		return "something";
	}

	@GetMapping("/hello")
	@ResponseBody
	public List<Product> sayHello() {
		List<Product> allProducts = productService.getAllProducts();
		return allProducts;
	}


	@GetMapping("/index")
	public ModelAndView showHome(Model model) {
		System.out.println("called");
		List<Book> bookList = bookService.getAllBooks();
		model.addAttribute("book", new Book());
		model.addAttribute("books", bookList);
		return new ModelAndView("index");
	}


	@GetMapping("/getAllProducts")
	public ModelAndView getAllProduct(Model model) {
		List<Product> allProducts = productService.getAllProducts();

		model.addAttribute("products", allProducts);
		return new ModelAndView("show_all_products");
	}

	@GetMapping("/getProduct/{id}")
	public ModelAndView getProduct(@PathVariable int id, Model model) {
		System.out.println("name: " + id);

		Product product = productService.getProductById(id);
		model.addAttribute("product", product);
		return new ModelAndView("show_product");
	}

	@GetMapping("/addProduct")
	public ModelAndView addProductForm() {
		System.out.println("get called");
		return new ModelAndView("add_product", "product", new Product());
	}

	@PostMapping("/addProduct")
	public ModelAndView addProduct(@Valid @ModelAttribute Product product, BindingResult result) {
		System.out.println("post called");
		if (result.hasErrors())
			return new ModelAndView("add_product", "product", product);
		else {
			boolean productAddedSuccessfully = productService.addProduct(product);
			if (productAddedSuccessfully) {
				System.out.println("success");
				List<Product> allProducts = productService.getAllProducts();
				return new ModelAndView("show_all_products", "products", allProducts);
			} else {
				System.out.println("failure");
				return new ModelAndView("error");
			}
		}

	}

	@GetMapping("/deleteProduct/{id}")
	public ModelAndView deleteProduct(@PathVariable int id, Model model) {
		System.out.println("delete called");
		System.out.println("success");
		Product product = productService.getProductById(id);
		List<Product> allProducts = productService.deleteProduct(product);
		if (allProducts.size() > 0)
			return new ModelAndView("show_all_products", "products", allProducts);
		else
			return new ModelAndView("add_product", "product", new Product());

	}
	@GetMapping("/editProduct/{id}")
	public ModelAndView editProduct(@PathVariable int id, Model model) {
		System.out.println("edit get called");
		Product product = productService.getProductById(id);
			return new ModelAndView("edit_product", "product", product);
	}
	@GetMapping("/findProductByName")
	public ModelAndView showFindProductByName() {
		System.out.println("find by name get called");
		return new ModelAndView("product_by_name");
	}
	@PostMapping("/findProductByName")
	public ModelAndView showFindProductByName(@RequestParam(name = "productName") String name, Model model) {
		System.out.println("find by name post called");
			Product product = new Product();
			product = productService.findProductByName(name);
			if (product != null) {
				System.out.println("success");
				List<Product> allProducts = new ArrayList<>();
				allProducts.add(product);
				return new ModelAndView("show_all_products", "products", allProducts);
			} else {
				System.out.println("failure");
				return new ModelAndView("error");
		}

	}
	@PostMapping("/editProduct")
	public ModelAndView editProduct(@ModelAttribute Product product) {
			boolean productUpdatedSuccessfully = productService.updateProduct(product);
			if (productUpdatedSuccessfully) {
				System.out.println("success");
				List<Product> allProducts = productService.getAllProducts();
				return new ModelAndView("show_all_products", "products", allProducts);
			} else {
				System.out.println("failure");
				return new ModelAndView("error");
		}

	}
	@GetMapping("/error")
	public ModelAndView error(Model model) {
		return new ModelAndView("error");
	}

}
