package com.cybage.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.cybage.model.Product;
import com.cybage.model.User;
import com.cybage.service.ProductService;

@Controller
public class UserController {

	@Autowired
	ProductService productService;

	@GetMapping("/signin")
	public ModelAndView getLoginUser(Model model) {
		System.out.println("login user get called");
		return new ModelAndView("signin", "user", new User());
	}

	@PostMapping("/signin")
	public RedirectView loginUser(@ModelAttribute User user, Model model) {
		if (user != null) {
			if (user.getUserEmail().equals("ray@cybage.com") && user.getUserPassword().equals("admin@123")) {
				return new RedirectView("/index");
			} 
		}
		return new RedirectView("/signin");
	}

	@GetMapping("/signup")
	public ModelAndView registerUser(Model model) {
		return new ModelAndView("sign-up", "user", new User());

	}

}
