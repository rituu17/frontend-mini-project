package com.cybage.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.cybage.model.Product;

@Service
public class ProductService {
	private List<Product> productList = new ArrayList<>();

	public ProductService() {
		productList.add(new Product(1, "mobile", 23000, 2));
		productList.add(new Product(2, "headphone", 2300, 3));
		productList.add(new Product(3, "laptop", 83000, 1));
		productList.add(new Product(4, "book", 530, 4));
	}

	public List<Product> getAllProducts() {
		return productList;
	}

	public Product getProductById(int id) {

		Product product1 = productList.stream().filter(product -> id == product.getProductId()).findAny()
				.orElse(new Product());

//		System.out.println("this is product name: " + product.getProductName());

		return product1;
	}

	public boolean addProduct(Product product) {
		productList.add(product);
		return true;
	}

	public List<Product> deleteProduct(Product product) {
		boolean success = productList.remove(product);
		if (success)
			return productList;
		else
			return new ArrayList<Product>();
	}

	public boolean updateProduct(@Valid Product product) {
		int index = productList.indexOf(getProductById(product.getProductId()));
		productList.set(index, product);
		return true;
	}

	public Product findProductByName(String name) {
		Product productByName = productList.stream().filter(product -> name.equalsIgnoreCase(product.getProductName()))
				.findAny()
				.orElse(new Product());
		if(productByName != null)
			return productByName;
		else 
			return null;
	}

}
