package com.cybage.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.cybage.model.Book;
import com.cybage.model.Product;

@Service
public class BookService {
	private List<Book> bookList = new ArrayList<>();

	public BookService() {
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
		bookList.add(new Book(1, "sadf", "asdf", "sdf"));
	}

	public List<Book> getAllBooks() {
		return bookList;
	}

//	public Product getProductById(int id) {
//
//		Product product1 = productList.stream().filter(product -> id == product.getProductId()).findAny()
//				.orElse(new Product());
//
////		System.out.println("this is product name: " + product.getProductName());
//
//		return product1;
//	}
//
//	public boolean addProduct(Product product) {
//		productList.add(product);
//		return true;
//	}
//
//	public List<Product> deleteProduct(Product product) {
//		boolean success = productList.remove(product);
//		if (success)
//			return productList;
//		else
//			return new ArrayList<Product>();
//	}
//
//	public boolean updateProduct(@Valid Product product) {
//		int index = productList.indexOf(getProductById(product.getProductId()));
//		productList.set(index, product);
//		return true;
//	}
//
//	public Product findProductByName(String name) {
//		Product productByName = productList.stream().filter(product -> name.equalsIgnoreCase(product.getProductName()))
//				.findAny()
//				.orElse(new Product());
//		if(productByName != null)
//			return productByName;
//		else 
//			return null;
//	}

}
